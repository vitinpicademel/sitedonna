<?php

$this->start_controls_section(
    'layout_two_content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_two'
        ]
    ]
);

$this->add_control(
    'layout_two_sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __('Awesome Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_two');

$this->add_control(
    'layout_two_sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __('Awesome Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_two');

$layout_two_service = new \Elementor\Repeater();

$layout_two_service->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'default' => __('Awesome Title', 'alipes-addon'),
        'label_block' => true,
    ]
);

alipes_elementor_heading_option($layout_two_service, 'Service Title', 'h3', 'layout_two');

$layout_two_service->add_control(
    'content',
    [
        'label' => __('Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::CODE,
        'default' =>  wp_kses('<li><div class="icon"><i class="fa fa-check"></i></div><div class="text"><p>Wake-up call</p></div></li>', 'alipes_allowed_tags'),
        'label_block' => true,
    ]
);

$layout_two_service->add_control(
    'url',
    [
        'label' => __('Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
    ]
);


$this->add_control(
    'layout_two_service_items',
    [
        'label' => __('Service Items', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $layout_two_service->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);

$this->end_controls_section();
