<?php

$this->start_controls_section(
    'content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'title',
    [
        'label' => __('Widget Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Newsletter', 'alipes-addon'),
        'label_block' => true
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h3', 'layout_one');

$this->add_control(
    'mailchimp_url',
    [
        'label' => __('Add Mailchimp URL', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => '#',
        'label_block' => true
    ]
);

$this->add_control(
    'mc_input_placeholder',
    [
        'label' => __('Input Placeholder Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Email address', 'alipes-addon'),
        'label_block' => true
    ]
);

$this->add_control(
    'btn_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Button Label', 'alipes-addon'),
        'label_block' => true
    ]
);

$this->end_controls_section();
