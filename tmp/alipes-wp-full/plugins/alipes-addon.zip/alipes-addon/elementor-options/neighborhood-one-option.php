<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_one');


$this->add_control(
    'sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_one');


$neighbour_faq = new \Elementor\Repeater();

$neighbour_faq->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
        'label_block' => true,
    ]
);

alipes_elementor_heading_option($neighbour_faq, 'Accordian Title', 'h4', 'layout_one');

$neighbour_faq->add_control(
    'sub_title',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Sub Title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
        'label_block' => true,
    ]
);

$neighbour_faq->add_control(
    'summary',
    [
        'label' => __('Summary', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add Summary', 'alipes-addon'),
        'default' => __('Default Summary', 'alipes-addon'),
        'label_block' => true,
    ]
);

$neighbour_faq->add_control(
    'active_status',
    [
        'label' => __('Is active?', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __('Yes', 'alipes-addon'),
        'label_off' => __('No', 'alipes-addon'),
        'return_value' => 'yes',
        'default' => 'no',
    ]
);


$this->add_control(
    'neighbour_faq_lists',
    [
        'label' => __('Neighborhood List', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $neighbour_faq->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);

$this->add_control(
    'bac_image_one',
    [
        'label' => __('Backround Image One', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
    ]
);

$this->add_control(
    'bac_image_two',
    [
        'label' => __('Backround Image Two', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
    ]
);


$this->end_controls_section();
