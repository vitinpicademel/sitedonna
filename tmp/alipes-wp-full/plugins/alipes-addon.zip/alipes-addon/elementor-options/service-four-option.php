<?php

$this->start_controls_section(
    'layout_four_content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_four'
        ]
    ]
);


$layout_four_service = new \Elementor\Repeater();

$layout_four_service->add_control(
    'icon',
    [
        'label' => __('Count Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'icon-tractor',
            'library' => 'custom-icon',
        ],
    ]
);

$layout_four_service->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __('Awesome Title', 'alipes-addon'),
        'label_block' => true,
    ]
);

alipes_elementor_heading_option($layout_four_service, 'Service Title', 'h3', 'layout_four');


$layout_four_service->add_control(
    'url',
    [
        'label' => __('Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
    ]
);

$layout_four_service->add_control(
    'text',
    [
        'label' => __('Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __('Default Text', 'alipes-addon'),
        'label_block' => true,
    ]
);

$layout_four_service->add_control(
    'image',
    [
        'label' => __('Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);


$this->add_control(
    'layout_four_service_items',
    [
        'label' => __('Service Items', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $layout_four_service->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);

$this->end_controls_section();
