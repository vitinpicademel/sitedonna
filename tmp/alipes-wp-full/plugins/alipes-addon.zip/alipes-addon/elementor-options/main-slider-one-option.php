<?php

$this->start_controls_section(
    'content_section',
    [
        'label' => __('Slider Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$sliders = new \Elementor\Repeater();

$sliders->add_control(
    'background_image',
    [
        'label' => __('Background Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$sliders->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Awesome Title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($sliders, 'Title', 'h2', 'layout_one');

$sliders->add_control(
    'sub_title',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add paragraph text', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($sliders, 'Sub Title', 'h4', 'layout_one');


$this->add_control(
    'sliders',
    [
        'label' => __('Main Slider', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $sliders->get_controls(),
        'title_field' => '{{{ title }}}',
        'prevent_empty' => false,
    ]
);

$this->end_controls_section();
