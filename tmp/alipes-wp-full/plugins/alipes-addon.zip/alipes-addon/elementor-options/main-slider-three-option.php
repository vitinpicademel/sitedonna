<?php

$this->start_controls_section(
    'layout_three_content_section',
    [
        'label' => __('Slider Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_three'
        ]
    ]
);

$layout_three_sliders = new \Elementor\Repeater();


$layout_three_sliders->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Awesome Title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($layout_three_sliders, 'Title', 'h2', 'layout_three');

$layout_three_sliders->add_control(
    'sub_title',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Sub Title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($layout_three_sliders, 'Sub Title', 'h5', 'layout_three');

$layout_three_sliders->add_control(
    'count_text',
    [
        'label' => __('Count Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Count text', 'alipes-addon'),
        'default' => __('Default Text', 'alipes-addon'),
        'label_block' => true
    ]
);

$layout_three_sliders->add_control(
    'count_number',
    [
        'label' => __('Count Number', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Count Number', 'alipes-addon'),
        'default' => __('36300', 'alipes-addon'),
        'label_block' => true
    ]
);

$layout_three_sliders->add_control(
    'count_icon',
    [
        'label' => __('Count Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'icon-apartment',
            'library' => 'count-icon',
        ],
    ]
);

$layout_three_sliders->add_control(
    'background_image',
    [
        'label' => __('Background Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$layout_three_sliders->add_control(
    'shape',
    [
        'label' => __('Shape', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);


$this->add_control(
    'layout_three_sliders',
    [
        'label' => __('Main Slider', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $layout_three_sliders->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);



$this->end_controls_section();
