<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$faq = new \Elementor\Repeater();

$faq->add_control(
    'question',
    [
        'label' => __('Question', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Question', 'alipes-addon'),
        'default' => __('Default Question', 'alipes-addon'),
        'label_block' => true,
    ]
);

alipes_elementor_heading_option($faq, 'Faq One Question', 'h4', 'layout_one');

$faq->add_control(
    'answer',
    [
        'label' => __('Answer', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add Answer', 'alipes-addon'),
        'default' => __('Default Answer', 'alipes-addon'),
        'label_block' => true,
    ]
);

$faq->add_control(
    'active_status',
    [
        'label' => __('Is active?', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __('Yes', 'alipes-addon'),
        'label_off' => __('No', 'alipes-addon'),
        'return_value' => 'yes',
        'default' => 'no',
    ]
);

$this->add_control(
    'faq_lists',
    [
        'label' => __('FAQ List One', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $faq->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ question }}}',
    ]
);


$faq_two = new \Elementor\Repeater();

$faq_two->add_control(
    'question',
    [
        'label' => __('Question', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Question', 'alipes-addon'),
        'default' => __('Default Question', 'alipes-addon'),
        'label_block' => true,
    ]
);

alipes_elementor_heading_option($faq_two, 'Faq Two Question', 'h4', 'layout_one');

$faq_two->add_control(
    'answer',
    [
        'label' => __('Answer', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add Answer', 'alipes-addon'),
        'default' => __('Default Answer', 'alipes-addon'),
        'label_block' => true,
    ]
);

$faq_two->add_control(
    'active_status',
    [
        'label' => __('Is active?', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __('Yes', 'alipes-addon'),
        'label_off' => __('No', 'alipes-addon'),
        'return_value' => 'yes',
        'default' => 'no',
    ]
);

$this->add_control(
    'faq_two_lists',
    [
        'label' => __('FAQ List Two', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $faq_two->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ question }}}',
    ]
);


$this->end_controls_section();
