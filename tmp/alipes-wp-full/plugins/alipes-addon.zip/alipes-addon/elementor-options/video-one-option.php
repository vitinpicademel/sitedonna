<?php

$this->start_controls_section(
    'layout_one_content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'layout_one_video_title',
    [
        'label' => __('Video Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Video Title', 'h3', 'layout_one');


$this->add_control(
    'layout_one_video_url',
    [
        'label' => __('Video Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Url', 'alipes-addon'),
        'default' => __('#', 'alipes-addon'),
        'label_block' => true
    ]
);

$this->add_control(
    'layout_one_bg_image',
    [
        'label' => __('Background Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->end_controls_section();
