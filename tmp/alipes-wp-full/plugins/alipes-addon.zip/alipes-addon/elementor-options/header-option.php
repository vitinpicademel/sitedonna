<?php


$this->start_controls_section(
    'logo_section',
    [
        'label' => __('Site Logo', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
);


$this->add_control(
    'light_logo',
    [
        'label' => __('Light Logo', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$this->add_control(
    'logo_dimension',
    [
        'label' => __('Logo Dimension', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::IMAGE_DIMENSIONS,
        'description' => __('Set Custom Logo Size.', 'alipes-addon'),
        'default' => [
            'width' => '39',
            'height' => '39',
        ],
    ]
);


$this->end_controls_section();

$this->start_controls_section(
    'nav_section',
    [
        'label' => __('Navigation', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
);

$this->add_control(
    'nav_menu',
    [
        'label' => __('Select Nav Menu', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'options' => alipes_get_nav_menu(),
        'label_block' => true,
    ]
);

$this->end_controls_section();

//top bar
$this->start_controls_section(
    'topbar_section',
    [
        'label' => __('Topbar', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => ['layout_one', 'layout_three']
        ]

    ]
);


$topbar_infos = new \Elementor\Repeater();

$topbar_infos->add_control(
    'topbar_icon',
    [
        'label' => __('Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'fas fa-map-marker-alt',
            'library' => 'custom',
        ],
        'label_block' => true,
    ]
);

$topbar_infos->add_control(
    'topbar_info_text',
    [
        'label' => __('Topbar Right Info Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'default' => __('30 Commercial Road Fratton, Australia ', 'alipes-addon'),
        'label_block' => true,
    ]
);


$this->add_control(
    'topbar_infos',
    [
        'label' => __('Topbar Info', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $topbar_infos->get_controls(),
        'title_field' => '{{{ topbar_info_text }}}',
    ]
);


$this->add_control(
    'topbar_time_info',
    [
        'label' => __('Time', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Mon to Sat: 8.00 am - 7.00 pm', 'alipes-addon'),
        'label_block' => true,
        'condition'   => [
            'layout_type' => ['layout_one', 'layout_three']
        ]
    ]
);

$this->end_controls_section();

//other
$this->start_controls_section(
    'others_section',
    [
        'label' => __('Others', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
);

$this->add_control(
    'search_enable',
    [
        'label' => __('Enable Search?', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __('Yes', 'alipes-addon'),
        'label_off' => __('No', 'alipes-addon'),
        'return_value' => 'yes',
        'default' => 'yes',
    ]
);

$this->add_control(
    'cart_enable',
    [
        'label' => __('Display Cart Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => __('Yes', 'alipes-addon'),
        'label_off' => __('No', 'alipes-addon'),
        'return_value' => 'yes',
        'default' => 'yes',
    ]
);

$nav_social_icons = new \Elementor\Repeater();

$nav_social_icons->add_control(
    'social_icon',
    [
        'label' => __('Select Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'fab fa-facebook-f',
            'library' => 'brand',
        ],
        'label_block' => true,
    ]
);

$nav_social_icons->add_control(
    'social_url',
    [
        'label' => __('Add Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => false,
    ]
);

$this->add_control(
    'nav_social_icons',
    [
        'label' => __('Social Icons', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $nav_social_icons->get_controls(),
        'prevent_empty' => false,
        'condition' => [
            'layout_type' => ['layout_one', 'layout_three']
        ],
        'default' => [
            [
                'social_url' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ],
        ],
    ]
);

$this->add_control(
    'button_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Get Free Quote', 'alipes-addon'),
        'label_block' => true,
    ]
);


$this->add_control(
    'button_url',
    [
        'label' => __('Button Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => true,
        'default' => [
            'url' => '#',
            'is_external' => true,
            'nofollow' => true,
        ],
        'show_label' => false,
    ]
);

$this->end_controls_section();

$this->start_controls_section(
    'mobile_menu_section',
    [
        'label' => __('Mobile Drawer', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
);


$this->add_control(
    'mobile_menu_logo',
    [
        'label' => __('Mobile Drawer Logo', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$this->add_control(
    'mobile_email',
    [
        'label' => __('Email', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Add Email', 'alipes-addon'),
        'label_block' => true,
    ]
);

$this->add_control(
    'mobile_phone',
    [
        'label' => __('Phone', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'placeholder' => __('Phone Number', 'alipes-addon'),
        'label_block' => true,
    ]
);

$mobile_menu_social_icons = new \Elementor\Repeater();

$mobile_menu_social_icons->add_control(
    'social_icon',
    [
        'label' => __('Select Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::SELECT2,
        'options' => alipes_get_fa_icons(),
        'default' => 'fa-facebook-f',
        'label_block' => true,
    ]
);

$mobile_menu_social_icons->add_control(
    'social_url',
    [
        'label' => __('Add Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => false,
    ]
);

$this->add_control(
    'mobile_menu_social_icons',
    [
        'label' => __('Social Icons', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $mobile_menu_social_icons->get_controls(),
        'prevent_empty' => false,
        'default' => [
            [
                'social_icon' => 'fa-facebook-f',
                'social_url' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ],
        ],
        'title_field' => '{{{ social_icon }}}',
    ]
);

$this->end_controls_section();
