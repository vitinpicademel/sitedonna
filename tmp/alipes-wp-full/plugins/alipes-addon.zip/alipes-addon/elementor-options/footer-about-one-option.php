<?php

$this->start_controls_section(
    'content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'logo',
    [
        'label' => __('Add Logo', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$this->add_control(
    'logo_dimension',
    [
        'label' => __('Logo Dimension', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::IMAGE_DIMENSIONS,
        'description' => __('Set Custom Logo Size.', 'alipes-addon'),
        'default' => [
            'width' => '134',
            'height' => '34',
        ],
    ]
);

$this->add_control(
    'text',
    [
        'label' => __('Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add paragraph text', 'alipes-addon'),
        'default' => __('Default text', 'alipes-addon'),
    ]
);

$this->end_controls_section();
