<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$feature_list = new \Elementor\Repeater();

$feature_list->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($feature_list, 'Feature Title', 'h3', 'layout_one');

$feature_list->add_control(
    'subtitle',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Sub Title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

$feature_list->add_control(
    'image',
    [
        'label' => __('Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [
            'url' => \Elementor\Utils::get_placeholder_image_src(),
        ],
    ]
);

$feature_list->add_control(
    'url',
    [
        'label' => __('Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => true,
    ]
);

$this->add_control(
    'feature_list_one',
    [
        'label' => __('Feature Lists', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $feature_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);

$this->end_controls_section();
