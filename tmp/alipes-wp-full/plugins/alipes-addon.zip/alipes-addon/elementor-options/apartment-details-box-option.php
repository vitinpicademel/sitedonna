<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
);

$appartment_details_box_list = new \Elementor\Repeater();

$appartment_details_box_list->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('130', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($appartment_details_box_list, 'Apartment Box Title', 'h3', 'layout_one');

$appartment_details_box_list->add_control(
    'subtitle',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('SQUARE AREAS', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($appartment_details_box_list, 'Apartment Box Sub Title', 'h5', 'layout_one');

$this->add_control(
    'layout_one_apartment_detail_box_list',
    [
        'label' => __('Box List One', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $appartment_details_box_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);


$this->end_controls_section();
