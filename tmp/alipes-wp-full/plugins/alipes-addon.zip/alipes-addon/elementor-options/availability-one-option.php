<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_one');

$this->add_control(
    'sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_one');


$availability_title_list = new \Elementor\Repeater();

$availability_title_list->add_control(
    'residance_title',
    [
        'label' => __('Residance Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Residance', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'room_title',
    [
        'label' => __('Room Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Room', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'bath_title',
    [
        'label' => __('Bath Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Bath', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'sq_fit_title',
    [
        'label' => __('Squre Fit Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('SQ.FT', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'floor_title',
    [
        'label' => __('Floor Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Floor', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'terrace_title',
    [
        'label' => __('Terrace Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Terrace', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_title_list->add_control(
    'plan_title',
    [
        'label' => __('Plan Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Plan', 'alipes-addon'),
        'label_block' => true,
    ]
);

$this->add_control(
    'availability_title_list',
    [
        'label' => __('Availability Title List', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $availability_title_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ residance_title }}}',
    ]
);

$this->add_control(
    'availability_title_hr',
    [
        'type' => \Elementor\Controls_Manager::DIVIDER,
    ]
);


$availability_content_list = new \Elementor\Repeater();

$availability_content_list->add_control(
    'residance_content',
    [
        'label' => __('Residance Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Amazon', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'room_content',
    [
        'label' => __('Room Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('3', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'bath_content',
    [
        'label' => __('Bath Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('2', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'squre_fit_content',
    [
        'label' => __('Squre Fit Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('660', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'floor_content',
    [
        'label' => __('Floor Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('2', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'terrace_content',
    [
        'label' => __('Terrace Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('1', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'button_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('View Details', 'alipes-addon'),
        'label_block' => true,
    ]
);

$availability_content_list->add_control(
    'url',
    [
        'label' => __('Button Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => true,
    ]
);

$this->add_control(
    'availability_content_list',
    [
        'label' => __('Availability Content List', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $availability_content_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ residance_content }}}',
    ]
);


$this->add_control(
    'bac_image_one',
    [
        'label' => __('Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);


$this->end_controls_section();
