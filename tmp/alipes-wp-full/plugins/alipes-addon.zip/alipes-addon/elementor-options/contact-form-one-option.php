<?php

$this->start_controls_section(
    'contact_form_section',
    [
        'label' => __('Contact Form', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'con_form_title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Contact Form Title', 'h2', 'layout_one');

$this->add_control(
    'con_form_sub_title',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Contact Form Sub Title', 'span', 'layout_one');


$this->add_control(
    'select_wpcf7_form',
    [
        'label'       => esc_html__('Select your contact form 7', 'alipes-addon'),
        'label_block' => true,
        'type'        => \Elementor\Controls_Manager::SELECT,
        'options'     => alipes_post_query('wpcf7_contact_form'),
    ]
);


$this->end_controls_section();

$this->start_controls_section(
    'content_section',
    [
        'label' => __('Contents', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_one');

$this->add_control(
    'sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_one');

$this->add_control(
    'con_person_image',
    [
        'label' => __('Contact Person Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->add_control(
    'con_person_name',
    [
        'label' => __('Contact Person Name', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Name', 'alipes-addon'),
        'default' => __('Default Name', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Contact Person Name', 'h3', 'layout_one');

$this->add_control(
    'con_person_title',
    [
        'label' => __('Contact Person Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Person Name', 'alipes-addon'),
        'default' => __('Default Person Name', 'alipes-addon'),
    ]
);

$this->add_control(
    'con_person_content',
    [
        'label' => __('Contact Person Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add Content', 'alipes-addon'),
        'default' => __('Default Content', 'alipes-addon'),
    ]
);

$layout_one_contact_info = new \Elementor\Repeater();

$layout_one_contact_info->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Have Question?', 'alipes-addon'),
    ]
);

$layout_one_contact_info->add_control(
    'content',
    [
        'label' => __('Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Content', 'alipes-addon'),
        'default' => wp_kses(__('<a href="tel:+9288008960">Free +92 (8800) - 8960</a>'), 'alipes_allowed_tags')
    ]
);

alipes_elementor_heading_option($layout_one_contact_info, 'Contact Info', 'h4', 'layout_one');

$layout_one_contact_info->add_control(
    'icon',
    [
        'label' => __('Check Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'fas fa-phone-alt',
            'library' => 'font-awesome',
        ],
    ]
);

$this->add_control(
    'layout_one_contact_info',
    [
        'label' => __('Contact Info', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $layout_one_contact_info->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'bg_shape',
    [
        'label' => __('Background Shape', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->end_controls_section();
