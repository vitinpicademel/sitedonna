<?php

//content
$this->start_controls_section(
    'content_two',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_two'
        ]
    ]
);

$counter_list_two = new \Elementor\Repeater();

$counter_list_two->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default  Text', 'alipes-addon'),
    ]
);

$counter_list_two->add_control(
    'number',
    [
        'label' => __('Number', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Number', 'alipes-addon'),
        'default' => __('680', 'alipes-addon'),
    ]
);

$counter_list_two->add_control(
    'icon',
    [
        'label' => __('Check Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'icon-ruler',
            'library' => 'font-awesome',
        ],
    ]
);

$this->add_control(
    'counter_list_two',
    [
        'label' => __('Check Lists', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $counter_list_two->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);


$this->add_control(
    'layout_two_bg_image',
    [
        'label' => __('Background Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->end_controls_section();
