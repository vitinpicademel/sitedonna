<?php

$this->start_controls_section(
    'content_section',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Title', 'h3', 'layout_one');

$this->add_control(
    'text',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add text', 'alipes-addon'),
        'default' => __('Default Text', 'alipes-addon'),
    ]
);

$this->add_control(
    'button_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Discover More', 'alipes-addon'),
        'label_block' => true,
    ]
);

$this->add_control(
    'button_url',
    [
        'label' => __('Button Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => true,
    ]
);


$this->add_control(
    'shape_one',
    [
        'label' => __('Shape One', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->add_control(
    'shape_two',
    [
        'label' => __('Shape Two', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->end_controls_section();
