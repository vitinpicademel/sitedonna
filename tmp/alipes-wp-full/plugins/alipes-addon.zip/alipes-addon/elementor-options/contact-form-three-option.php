<?php

$this->start_controls_section(
    'layout_three_contact_form',
    [
        'label' => __('Contact Form', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_three'
        ]
    ]
);

$this->add_control(
    'layout_three_sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_three');

$this->add_control(
    'layout_three_sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_three');

$this->add_control(
    'layout_three_text',
    [
        'label' => __('Section Text', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add Text', 'alipes-addon'),
        'default' => __('Default Text', 'alipes-addon'),
    ]
);


$this->add_control(
    'layout_three_select_wpcf7_form',
    [
        'label'       => esc_html__('Select your contact form 7', 'alipes-addon'),
        'label_block' => true,
        'type'        => \Elementor\Controls_Manager::SELECT,
        'options'     => alipes_post_query('wpcf7_contact_form'),
    ]
);

$layout_three_contact_info = new \Elementor\Repeater();

$layout_three_contact_info->add_control(
    'content',
    [
        'label' => __('Content', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Content', 'alipes-addon'),
        'default' => wp_kses(__('<a href="tel:9200368090">+92 (003) 68-090</a> <br> <a href="mailto:needhelp@company.com">needhelp@company.com</a>'), 'alipes_allowed_tags')
    ]
);

$layout_three_contact_info->add_control(
    'icon',
    [
        'label' => __('Check Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'fas fa-phone',
            'library' => 'font-awesome',
        ],
    ]
);

$this->add_control(
    'layout_three_contact_info',
    [
        'label' => __('Contact Info', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $layout_three_contact_info->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ content }}}',
    ]
);

$this->add_control(
    'layout_three_shape_one',
    [
        'label' => __('Shape One', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);

$this->end_controls_section();
