<?php

//content
$this->start_controls_section(
    'content_one',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_one'
        ]
    ]
);

$this->add_control(
    'sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_one');

$this->add_control(
    'sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_one');


$amenities_list = new \Elementor\Repeater();

$amenities_list->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title  Text', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($amenities_list, 'Amenities Title', 'h3', 'layout_one');

$amenities_list->add_control(
    'subtitle',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add Title', 'alipes-addon'),
        'default' => __('Default Sub Title Text', 'alipes-addon'),
    ]
);

$amenities_list->add_control(
    'icon',
    [
        'label' => __('Check Icon', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::ICONS,
        'default' => [
            'value' => 'icon-town',
            'library' => 'font-awesome',
        ],
    ]
);

$amenities_list->add_control(
    'button_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('Button Label', 'alipes-addon'),
        'label_block' => true,
    ]
);

$amenities_list->add_control(
    'url',
    [
        'label' => __('Button Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => true,
    ]
);

$this->add_control(
    'amenities_list',
    [
        'label' => __('Amenities List', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $amenities_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);

$this->add_control(
    'layout_one_bg_shape',
    [
        'label' => __('Shape', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);


$this->end_controls_section();
