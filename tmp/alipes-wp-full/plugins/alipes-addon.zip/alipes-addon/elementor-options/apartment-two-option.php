<?php

//content
$this->start_controls_section(
    'content_two',
    [
        'label' => __('Content', 'alipes-addon'),
        'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        'condition' => [
            'layout_type' => 'layout_two'
        ]
    ]
);

$this->add_control(
    'layout_two_sec_title',
    [
        'label' => __('Section Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add title', 'alipes-addon'),
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Title', 'h2', 'layout_two');

$this->add_control(
    'layout_two_sec_sub_title',
    [
        'label' => __('Section Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => '2',
        'placeholder' => __('Add sub title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($this, 'Section Sub Title', 'span', 'layout_two');

$apartment_two_list = new \Elementor\Repeater();

$apartment_two_list->add_control(
    'title',
    [
        'label' => __('Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'placeholder' => __('Add title', 'alipes-addon'),
        'rows'  => '2',
        'default' => __('Default Title', 'alipes-addon'),
    ]
);

alipes_elementor_heading_option($apartment_two_list, 'Apartment Title', 'h3', 'layout_two');

$apartment_two_list->add_control(
    'subtitle',
    [
        'label' => __('Sub Title', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows'  => '2',
        'placeholder' => __('Add Sub Title', 'alipes-addon'),
        'default' => __('Default Sub Title', 'alipes-addon'),
    ]
);

$apartment_two_list->add_control(
    'image',
    [
        'label' => __('Image', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::MEDIA,
        'default' => [],
    ]
);


$apartment_two_list->add_control(
    'button_label',
    [
        'label' => __('Button Label', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => __('120 m2', 'alipes-addon'),
        'label_block' => true,
    ]
);

$apartment_two_list->add_control(
    'url',
    [
        'label' => __('Button Url', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => __('#', 'alipes-addon'),
        'show_external' => false,
        'default' => [
            'url' => '#',
            'is_external' => false,
            'nofollow' => false,
        ],
        'show_label' => true,
    ]
);

$this->add_control(
    'layout_two_apartment_list',
    [
        'label' => __('Apartment Lists', 'alipes-addon'),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $apartment_two_list->get_controls(),
        'prevent_empty' => false,
        'title_field' => '{{{ title }}}',
    ]
);


$this->end_controls_section();
