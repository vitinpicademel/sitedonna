<?php

namespace Layerdrops\Alipes;

class Assets
{

    /**
     * Class constructor
     */
    function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('admin_enqueue_scripts', [$this, 'register_assets']);
    }

    /**
     * All available scripts
     *
     * @return array
     */
    public function get_scripts()
    {
        return [
            'bootstrap-select' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/bootstrap-select/js/bootstrap-select.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/bootstrap-select/js/bootstrap-select.min.js'),
                'deps'    => ['jquery', 'bootstrap']
            ],
            'jquery-bxslider' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/bxslider/jquery.bxslider.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/bxslider/jquery.bxslider.min.js'),
                'deps'    => ['jquery']
            ],
            'countdown' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/countdown/countdown.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/countdown/countdown.min.js'),
                'deps'    => ['jquery']
            ],
            'jarallax' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jarallax/jarallax.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jarallax/jarallax.min.js'),
                'deps'    => ['jquery']
            ],
            'jquery-ajaxchimp' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js'),
                'deps'    => ['jquery']
            ],
            'jquery-appear' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jquery-appear/jquery.appear.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jquery-appear/jquery.appear.min.js'),
                'deps'    => ['jquery']
            ],
            'jquery-circle-progress' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jquery-circle-progress/jquery.circle-progress.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jquery-circle-progress/jquery.circle-progress.min.js'),
                'deps'    => ['jquery']
            ],
            'jquery-magnific-popup' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js'),
                'deps'    => ['jquery']
            ],
            'odometer' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/odometer/odometer.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/odometer/odometer.min.js'),
                'deps'    => ['jquery']
            ],
            'owl-carousel' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/owl-carousel/owl.carousel.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/owl-carousel/owl.carousel.min.js'),
                'deps'    => ['jquery']
            ],
            'swiper' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/swiper/swiper.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/swiper/swiper.min.js'),
                'deps'    => ['jquery']
            ],
            'wow' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/wow/wow.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/wow/wow.js'),
                'deps'    => ['jquery']
            ],

            'sharer' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/sharer/sharer.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/sharer/sharer.min.js'),
                'deps'    => ['jquery']
            ],

            'select2' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/select2/js/select2.min.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/select2/js/select2.min.js'),
                'deps'    => ['jquery']
            ],
            'alipes-addon-customizer' => [
                'src'     => ALIPES_ADDON_ASSETS . '/js/alipes-addon-customizer.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/js/alipes-addon-customizer.js'),
                'deps'    => ['jquery', 'select2']
            ],
            'alipes-addon-script' => [
                'src'     => ALIPES_ADDON_ASSETS . '/js/alipes-addon.js',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/js/alipes-addon.js'),
                'deps'    => ['jquery']
            ]
        ];
    }

    /**
     * All available styles
     *
     * @return array
     */
    public function get_styles()
    {
        return [
            'animate' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/animate/animate.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/animate/animate.min.css')
            ],
            'custom-animate' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/animate/custom-animate.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/animate/custom-animate.css')
            ],
            'bootstrap-select' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/bootstrap-select/css/bootstrap-select.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/bootstrap-select/css/bootstrap-select.min.css')
            ],
            'bxslider' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/bxslider/jquery.bxslider.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/bxslider/jquery.bxslider.css')
            ],
            'jarallax' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jarallax/jarallax.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jarallax/jarallax.css')
            ],
            'jquery-magnific-popup' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/jquery-magnific-popup/jquery.magnific-popup.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css')
            ],
            'odometer' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/odometer/odometer.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/odometer/odometer.min.css')
            ],
            'owl-carousel' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/owl-carousel/owl.carousel.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/owl-carousel/owl.carousel.min.css')
            ],
            'owl-theme' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/owl-carousel/owl.theme.default.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/owl-carousel/owl.theme.default.min.css')
            ],
            'reey-font' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/reey-font/stylesheet.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/reey-font/stylesheet.css')
            ],
            'swiper' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/swiper/swiper.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/swiper/swiper.min.css')
            ],
            'select2' => [
                'src'     => ALIPES_ADDON_ASSETS . '/vendors/select2/css/select2.min.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/vendors/select2/css/select2.min.css')
            ],
            'alipes-addon-style' => [
                'src'     => ALIPES_ADDON_ASSETS . '/css/alipes-addon.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/css/alipes-addon.css')
            ],
            'alipes-addon-admin-style' => [
                'src'     => ALIPES_ADDON_ASSETS . '/css/alipes-addon-admin.css',
                'version' => filemtime(ALIPES_ADDON_PATH . '/assets/css/alipes-addon-admin.css')
            ]
        ];
    }

    /**
     * Register scripts and styles
     *
     * @return void
     */
    public function register_assets()
    {
        $scripts = $this->get_scripts();
        $styles  = $this->get_styles();

        foreach ($scripts as $handle => $script) {
            $deps = isset($script['deps']) ? $script['deps'] : false;

            wp_register_script($handle, $script['src'], $deps, $script['version'], true);
        }

        foreach ($styles as $handle => $style) {
            $deps = isset($style['deps']) ? $style['deps'] : false;

            wp_register_style($handle, $style['src'], $deps, $style['version']);
        }
    }
}
