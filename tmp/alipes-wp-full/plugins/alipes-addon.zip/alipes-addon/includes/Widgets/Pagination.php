<?php

namespace Layerdrops\Alipes\Widgets;


class Pagination extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-pagination';
    }

    public function get_title()
    {
        return __('Pagination', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                ]
            ]
        );


        $this->end_controls_section();

        include alipes_get_elementor_option('pagination-one-option.php');


        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Text', '{{WRAPPER}} .project-details__pagination li p', ['layout_one', 'layout_two', 'layout_three']);

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        include alipes_get_template('pagination-one.php');
    }
}
