<?php

namespace Layerdrops\Alipes\Widgets;


class Testimonials extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-testimonials';
    }

    public function get_title()
    {
        return __('Testimonials', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {


        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                    'layout_four' => __('Layout Four', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('testimonial-one-option.php');
        include alipes_get_elementor_option('testimonial-two-option.php');
        include alipes_get_elementor_option('testimonial-three-option.php');
        include alipes_get_elementor_option('testimonial-four-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Section Content', '{{WRAPPER}} .testimonial-one__reviews-box p,{{WRAPPER}} .testimonial-two__top-text', ['layout_one', 'layout_two']);

        alipes_elementor_general_style_options($this, 'Name', '{{WRAPPER}} .testimonial-one__client-name,{{WRAPPER}} .testimonial-two__client-name', ['layout_one', 'layout_two', 'layout_three', 'layout_four']);
        alipes_elementor_general_style_options($this, 'Designation', '{{WRAPPER}} .testimonial-one__client-title,{{WRAPPER}} .testimonial-two__client-sub-title', ['layout_one', 'layout_two', 'layout_three', 'layout_four']);
        alipes_elementor_general_style_options($this, 'Content', '{{WRAPPER}} .testimonial-one__text,{{WRAPPER}} .testimonial-two__text', ['layout_one', 'layout_two', 'layout_three', 'layout_four']);
        alipes_elementor_general_style_options($this, 'Rating', '{{WRAPPER}} .testimonial-one__rating i,{{WRAPPER}} .testimonial-two__client-rating i', ['layout_one', 'layout_two', 'layout_three', 'layout_four']);
        alipes_elementor_general_style_options($this, 'Quote', '{{WRAPPER}} .testimonial-two__quote span', ['layout_two', 'layout_three', 'layout_four']);

        $this->end_controls_section();

        //button style
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__('Button Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        alipes_elementor_button_style_options($this, 'Section Rating Button', '{{WRAPPER}} .testimonial-one__reviews span', '{{WRAPPER}} .testimonial-one__reviews span:hover', ['layout_one']);

        $this->end_controls_section();


        alipes_get_elementor_carousel_options($this, ['layout_one', 'layout_two', 'layout_four']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('testimonials-one.php');
        include alipes_get_template('testimonials-two.php');
        include alipes_get_template('testimonials-three.php');
        include alipes_get_template('testimonials-four.php');
    }
}
