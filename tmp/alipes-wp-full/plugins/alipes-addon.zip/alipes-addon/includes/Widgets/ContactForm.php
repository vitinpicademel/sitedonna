<?php

namespace Layerdrops\Alipes\Widgets;


class ContactForm extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-contact-form';
    }

    public function get_title()
    {
        return __('Contact Form', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('contact-form-one-option.php');
        include alipes_get_elementor_option('contact-form-two-option.php');
        include alipes_get_elementor_option('contact-form-three-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Section Text', '{{WRAPPER}} .contact-two__text', ['layout_three']);

        alipes_elementor_general_style_options($this, 'Person Name', '{{WRAPPER}} .contact-one__person-name', ['layout_one']);
        alipes_elementor_general_style_options($this, 'Person Designation', '{{WRAPPER}} .contact-one__person-sub-title', ['layout_one']);
        alipes_elementor_general_style_options($this, 'Person Content', '{{WRAPPER}} .contact-one__person-text', ['layout_one']);

        alipes_elementor_general_style_options($this, 'Contact Info Title', '{{WRAPPER}} .content p', ['layout_one']);
        alipes_elementor_general_style_options($this, 'Contact Info Content', '{{WRAPPER}} .content h4, {{WRAPPER}} .content h4 a,{{WRAPPER}} .contact-two__number-email a', ['layout_one', 'layout_three']);

        alipes_elementor_general_style_options($this, 'Contact Form Title', '{{WRAPPER}} .contact-one__right .section-title__title', ['layout_one']);
        alipes_elementor_general_style_options($this, 'Contact Form Content', '{{WRAPPER}} .content h4, {{WRAPPER}} .contact-one__right .section-title__tagline', ['layout_one']);

        $this->end_controls_section();

        //button style
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__('Button Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_button_style_options($this, 'Contact Info Icon', '{{WRAPPER}} .contact-one__points li .icon span,{{WRAPPER}} .contact-two__call-icon', '{{WRAPPER}} .contact-one__points li .icon span:hover,{{WRAPPER}} .contact-two__call-icon:hover', ['layout_one', 'layout_three']);
        alipes_elementor_button_style_options($this, 'Contact Button', '{{WRAPPER}} .thm-btn', '{{WRAPPER}} .thm-btn:before', ['layout_one', 'layout_two', 'layout_three']);

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('contact-form-one.php');
        include alipes_get_template('contact-form-two.php');
        include alipes_get_template('contact-form-three.php');
    }
}
