<?php

namespace Layerdrops\Alipes\Widgets;

class ApartmentListBox extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-apartment-details-list-box';
    }

    public function get_title()
    {
        return __('Apartment Details List Box', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('apartment-details-box-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Title', '{{WRAPPER}} .apartment-details-one__list-content h3,{{WRAPPER}} .apartment-details-two-list__content h3', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Sub Title', '{{WRAPPER}} .apartment-details-one__list-content h5,{{WRAPPER}} .apartment-details-two-list__content h5', ['layout_one', 'layout_two']);

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('apartment-details-box-one.php');
        include alipes_get_template('apartment-details-box-two.php');
    }
}
