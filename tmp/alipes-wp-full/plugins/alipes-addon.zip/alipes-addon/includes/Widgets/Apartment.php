<?php

namespace Layerdrops\Alipes\Widgets;

class Apartment extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-apartment';
    }

    public function get_title()
    {
        return __('Apartment', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                    'layout_four' => __('Layout Four', 'alipes-addon'),
                    'layout_five' => __('Layout Five', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('apartment-one-option.php');
        include alipes_get_elementor_option('apartment-two-option.php');
        include alipes_get_elementor_option('apartment-three-option.php');
        include alipes_get_elementor_option('apartment-four-option.php');
        include alipes_get_elementor_option('apartment-five-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Apartment Title', '{{WRAPPER}} .apartment-one__title a,{{WRAPPER}} .apartment-two__title a,{{WRAPPER}}  .apartment-three__title a', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
        alipes_elementor_general_style_options($this, 'Apartment Sub Title', '{{WRAPPER}} .apartment-two__sub-title,{{WRAPPER}} .apartment-three__sub-title', ['layout_two', 'layout_three']);

        alipes_elementor_general_style_options($this, 'Icon', '{{WRAPPER}} .apartment-three__list li .icon span', ['layout_three']);
        alipes_elementor_general_style_options($this, 'Icon Title', '{{WRAPPER}} .apartment-three__list li p', ['layout_three']);


        $this->end_controls_section();

        //button style
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__('Button Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_type' => ['layout_one', 'layout_two', 'layout_four', 'layout_five']
                ]
            ]
        );

        alipes_elementor_button_style_options($this, 'Button', '{{WRAPPER}} .apartment-one__btn', '{{WRAPPER}} .apartment-one__btn::before', ['layout_one', 'layout_two', 'layout_four', 'layout_five']);

        $this->end_controls_section();
        alipes_get_elementor_carousel_options($this, ['layout_four']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('apartment-one.php');
        include alipes_get_template('apartment-two.php');
        include alipes_get_template('apartment-three.php');
        include alipes_get_template('apartment-four.php');
        include alipes_get_template('apartment-five.php');
    }
}
