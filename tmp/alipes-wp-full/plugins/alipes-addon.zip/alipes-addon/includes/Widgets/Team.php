<?php

namespace Layerdrops\Alipes\Widgets;


class Team extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-team';
    }

    public function get_title()
    {
        return __('Team', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('team-one-option.php');
        include alipes_get_elementor_option('team-two-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one']);

        alipes_elementor_general_style_options($this, 'Name', '{{WRAPPER}} .team-one__name a', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Designation', '{{WRAPPER}} .team-one__sub-title', ['layout_one', 'layout_two', 'layout_three']);

        $this->end_controls_section();

        alipes_get_elementor_carousel_options($this,  'layout_two');
        alipes_elementor_column_count_options($this, ['layout_one']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('team-one.php');
        include alipes_get_template('team-two.php');
    }
}
