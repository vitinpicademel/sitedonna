<?php

namespace Layerdrops\Alipes\Widgets;


class Service extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-service';
    }

    public function get_title()
    {
        return __('Service', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                ]
            ]
        );


        $this->end_controls_section();

        include alipes_get_elementor_option('service-one-option.php');
        include alipes_get_elementor_option('service-two-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two']);

        alipes_elementor_general_style_options($this, 'Service Title', '{{WRAPPER}} .services-one__title a,{{WRAPPER}} .services-three__title a', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Service Summary', '{{WRAPPER}} .services-one__text,{{WRAPPER}} .services-three__list li .text', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Service Icon', '{{WRAPPER}} .services-one__icon span', ['layout_one']);
        $this->add_control(
            'service_pointlist_icon_color',
            [
                'label' => __('Point List Icon Color', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-three__list li .icon' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'layout_type' => ['layout_two']
                ]

            ]
        );

        $this->add_control(
            'service_pointlist_icon_bg_color',
            [
                'label' => __('Point List Icon Bg Color', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-three__list li .icon' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
                    'layout_type' => ['layout_two']
                ]

            ]
        );

        $this->end_controls_section();

        //button style
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__('Button Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        alipes_elementor_button_style_options($this, 'Button', '{{WRAPPER}} .thm-btn', '{{WRAPPER}} .thm-btn:before', ['layout_one']);

        $this->end_controls_section();

        alipes_elementor_column_count_options($this, ['layout_one', 'layout_two']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('service-one.php');
        include alipes_get_template('service-two.php');
    }
}
