<?php

namespace Layerdrops\Alipes\Widgets;


class Gallery extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-gallery-slider';
    }

    public function get_title()
    {
        return __('Gallery', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                    'layout_four' => __('Layout Four', 'alipes-addon'),
                    'layout_five' => __('Layout Five', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('gallery-one-option.php');
        include alipes_get_elementor_option('gallery-two-option.php');
        include alipes_get_elementor_option('gallery-three-option.php');
        include alipes_get_elementor_option('gallery-four-option.php');
        include alipes_get_elementor_option('gallery-five-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .gallery-two .section-title__title', ['layout_two']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_two']);

        alipes_elementor_general_style_options($this, 'Title', '{{WRAPPER}} .gallery-one__title a,{{WRAPPER}} .gallery-two__title a,{{WRAPPER}} .gallery-three__title h3', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Sub Title', '{{WRAPPER}} .gallery-one__sub-title,{{WRAPPER}} .gallery-two__sub-title', ['layout_one', 'layout_two']);

        $this->end_controls_section();

        alipes_get_elementor_carousel_options($this, ['layout_one', 'layout_two', 'layout_five']);
        alipes_elementor_column_count_options($this, ['layout_three']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('gallery-one.php');
        include alipes_get_template('gallery-two.php');
        include alipes_get_template('gallery-three.php');
        include alipes_get_template('gallery-four.php');
        include alipes_get_template('gallery-five.php');
    }
}
