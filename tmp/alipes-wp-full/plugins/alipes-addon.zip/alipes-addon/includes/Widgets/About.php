<?php

namespace Layerdrops\Alipes\Widgets;


class About extends \Elementor\Widget_Base
{
	public function get_name()
	{
		return 'alipes-about';
	}

	public function get_title()
	{
		return __('About', 'alipes-addon');
	}

	public function get_icon()
	{
		return 'eicon-cogs';
	}

	public function get_categories()
	{
		return ['alipes-category'];
	}

	protected function register_controls()
	{
		$this->start_controls_section(
			'layout_section',
			[
				'label' => __('Layout', 'alipes-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout_type',
			[
				'label' => __('Select Layout', 'alipes-addon'),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'default' => 'layout_one',
				'options' => [
					'layout_one' => __('Layout One', 'alipes-addon'),
					'layout_two' => __('Layout Two', 'alipes-addon'),
					'layout_three' => __('Layout Three', 'alipes-addon'),
					'layout_four' => __('Layout Four', 'alipes-addon'),
					'layout_five' => __('Layout Five', 'alipes-addon'),
				]
			]
		);

		$this->end_controls_section();

		include alipes_get_elementor_option('about-one-option.php');
		include alipes_get_elementor_option('about-two-option.php');
		include alipes_get_elementor_option('about-three-option.php');
		include alipes_get_elementor_option('about-four-option.php');
		include alipes_get_elementor_option('about-five-option.php');

		//General style
		$this->start_controls_section(
			'general_style',
			[
				'label' => esc_html__('Content Style', 'alipes-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
		alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
		alipes_elementor_general_style_options($this, 'Section Summary', '{{WRAPPER}} .about-two__text-1,{{WRAPPER}} .about-three__text,{{WRAPPER}} .about-building__text-1,{{WRAPPER}} .about-four__text-1', ['layout_two', 'layout_three', 'layout_four', 'layout_five']);
		alipes_elementor_general_style_options($this, 'Section Summary Two', '{{WRAPPER}} .about-building__text-2', ['layout_four']);

		alipes_elementor_general_style_options($this, 'Featured Title', '{{WRAPPER}} .about-two__points-list li .text p', 'layout_two');
		alipes_elementor_general_style_options($this, 'Year', '{{WRAPPER}} .about-two__year h3', 'layout_two');
		alipes_elementor_general_style_options($this, 'Year Title', '{{WRAPPER}} .about-two__year p', 'layout_two');

		alipes_elementor_general_style_options($this, 'Counter Number', '{{WRAPPER}} .about-two__count-box h3', 'layout_two');
		alipes_elementor_general_style_options($this, 'Counter Title', '{{WRAPPER}} .about-two__text', 'layout_two');

		alipes_elementor_general_style_options($this, 'Highlighted Text', '{{WRAPPER}} .about-one__text-1', 'layout_one');
		alipes_elementor_general_style_options($this, 'Summary Text', '{{WRAPPER}} .about-one__text-2', ['layout_one']);

		alipes_elementor_general_style_options($this, 'Check List Title', '{{WRAPPER}} .about-one__points-list-content .text h3,{{WRAPPER}} .about-three__points li .text p,{{WRAPPER}} .about-four__points li .text p', ['layout_one', 'layout_three', 'layout_five']);
		alipes_elementor_general_style_options($this, 'Check List Content', '{{WRAPPER}} .about-one__points-text', ['layout_one']);

		$this->add_control(
			'checklist_icon_color',
			[
				'label' => __('Check List Icon Color', 'alipes-addon'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-one__points-list-content .icon span,{{WRAPPER}} .about-two__points-list li .icon span,{{WRAPPER}} .about-three__points li .icon span,{{WRAPPER}} .about-four__points li .icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'layout_type' => ['layout_one', 'layout_two', 'layout_three', 'layout_five']
				]

			]
		);

		$this->add_control(
			'checklist_icon_bg_color',
			[
				'label' => __('Check List Icon Bg Color', 'alipes-addon'),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .about-one__points-list-content .icon span, {{WRAPPER}} .about-two__points-list li .icon span, {{WRAPPER}} .about-three__points li .icon span,{{WRAPPER}} .about-four__points li .icon' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'layout_type' => ['layout_one', 'layout_two', 'layout_three', 'layout_five']
				]

			]
		);

		$this->end_controls_section();

		//button style
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__('Button Style', 'alipes-addon'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_type' => ['layout_one', 'layout_two']
				]
			]
		);

		alipes_elementor_button_style_options($this, 'Button', '{{WRAPPER}} .thm-btn', '{{WRAPPER}} .thm-btn:before', ['layout_one', 'layout_two']);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();

		include alipes_get_template('about-one.php');
		include alipes_get_template('about-two.php');
		include alipes_get_template('about-three.php');
		include alipes_get_template('about-four.php');
		include alipes_get_template('about-five.php');
	}
}
