<?php

namespace Layerdrops\Alipes\Widgets;


class MainSlider extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-main-slider';
    }

    public function get_title()
    {
        return __('Main Slider', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                ]
            ]
        );


        $this->end_controls_section();

        include alipes_get_elementor_option('main-slider-one-option.php');
        include alipes_get_elementor_option('main-slider-two-option.php');
        include alipes_get_elementor_option('main-slider-three-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Title', '{{WRAPPER}} .main-slider__title,{{WRAPPER}} .main-slider-two__title, {{WRAPPER}} .main-slider-three__title', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Sub Title', '{{WRAPPER}} .main-slider__sub-title,{{WRAPPER}} .main-slider-two__text,{{WRAPPER}} .main-slider-three__details-sub-title', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Sub Title Span', '{{WRAPPER}} .main-slider__sub-title span', ['layout_one'], 'background-color');

        alipes_elementor_general_style_options($this, 'Counter', '{{WRAPPER}} .main-slider-three__details-content h3', ['layout_three']);
        alipes_elementor_general_style_options($this, 'Counter Text', '{{WRAPPER}} .main-slider-three__details-text', ['layout_three']);
        alipes_elementor_general_style_options($this, 'Icon', '{{WRAPPER}} .main-slider-three__details-icon span', ['layout_three']);

        $this->end_controls_section();

        //button style
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__('Button Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_button_style_options($this, 'Button', '{{WRAPPER}} .thm-btn.main-slider__btn,{{WRAPPER}} a.thm-btn', '{{WRAPPER}} .main-slider__btn:before,{{WRAPPER}} .main-slider-two__btn:before', ['layout_one']);

        $this->end_controls_section();

        alipes_get_elementor_carousel_options($this, ['layout_one', 'layout_two', 'layout_three']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('main-slider-one.php');
        include alipes_get_template('main-slider-two.php');
        include alipes_get_template('main-slider-three.php');
    }
}
