<?php

namespace Layerdrops\Alipes\Widgets;


class Values extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-values';
    }

    public function get_title()
    {
        return __('Values', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include alipes_get_elementor_option('values-one-option.php');
        include alipes_get_elementor_option('values-two-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Subtitle', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two']);
        alipes_elementor_general_style_options($this, 'Summary', '{{WRAPPER}} .values-one__text,{{WRAPPER}} .values-two__text-1', ['layout_one', 'layout_two']);

        alipes_elementor_general_style_options($this, 'Point List Title', '{{WRAPPER}} .values-one__points li .text p,{{WRAPPER}} .values-two__points li .text p', ['layout_one', 'layout_two']);

        $this->add_control(
            'values_pointlist_icon_color',
            [
                'label' => __('Point List Icon Color', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .values-two__points li .icon,{{WRAPPER}} .values-one__points li .icon span' => 'color: {{VALUE}}',
                ],

            ]
        );

        $this->add_control(
            'values_pointlist_icon_bg_color',
            [
                'label' => __('Point List Icon Bg Color', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .values-two__points li .icon,{{WRAPPER}} .values-one__points li .icon span' => 'background-color: {{VALUE}}',
                ],

            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('values-one.php');
        include alipes_get_template('values-two.php');
    }
}
