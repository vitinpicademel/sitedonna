<?php

namespace Layerdrops\Alipes\Widgets;


class Blog extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-blog';
    }

    public function get_title()
    {
        return __('Blog', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                    'layout_three' => __('Layout Three', 'alipes-addon'),
                    'layout_four' => __('Layout Four', 'alipes-addon'),
                    'layout_five' => __('Layout Five', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        include  alipes_get_elementor_option('blog-option.php');

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        alipes_elementor_general_style_options($this, 'Section Title', '{{WRAPPER}} .section-title__title', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Section Sub Title', '{{WRAPPER}} .section-title__tagline', ['layout_one', 'layout_two', 'layout_three']);
        alipes_elementor_general_style_options($this, 'Section Summary', '{{WRAPPER}} .news-three__text', ['layout_three']);

        alipes_elementor_general_style_options($this, 'Post Title', '{{WRAPPER}} .news-one__title a', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
        alipes_elementor_general_style_options($this, 'Post Meta', '{{WRAPPER}} .news-one__meta li a', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
        alipes_elementor_general_style_options($this, 'Post Meta Icon', '{{WRAPPER}} .news-one__meta li a i, {{WRAPPER}} .news-one__meta li span i, {{WRAPPER}} .news-one__comment a i', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);

        alipes_elementor_general_style_options($this, 'Post Date', '{{WRAPPER}} .news-one__date p', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);
        alipes_elementor_general_style_options($this, 'Read More', '{{WRAPPER}} .news-one__button a', ['layout_one', 'layout_two', 'layout_three', 'layout_four', 'layout_five']);

        $this->end_controls_section();

        alipes_elementor_column_count_options($this, ['layout_one', 'layout_two', 'layout_three', 'layout_four']);
        alipes_get_elementor_carousel_options($this, ['layout_five']);
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('blog-one.php');
        include alipes_get_template('blog-two.php');
        include alipes_get_template('blog-three.php');
        include alipes_get_template('blog-four.php');
        include alipes_get_template('blog-five.php');
    }
}
