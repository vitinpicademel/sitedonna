<?php

namespace Layerdrops\Alipes\Widgets;


class Shape extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'alipes-shape';
    }

    public function get_title()
    {
        return __('Shape', 'alipes-addon');
    }

    public function get_icon()
    {
        return 'eicon-cogs';
    }

    public function get_categories()
    {
        return ['alipes-category'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_type',
            [
                'label' => __('Select Layout', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'default' => 'layout_one',
                'options' => [
                    'layout_one' => __('Layout One', 'alipes-addon'),
                    'layout_two' => __('Layout Two', 'alipes-addon'),
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'layout_one_content_section',
            [
                'label' => __('Content', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'shape_one',
            [
                'label' => __('Shape One', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [],
            ]
        );

        $this->add_responsive_control(
            'animation_top',
            [
                'label' => esc_html__('Top', 'cleanu-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .apartment-three__shape-1' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        $this->add_responsive_control(
            'animation_buttom',
            [
                'label' => esc_html__('Buttom', 'cleanu-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} apartment-three__shape-1' => 'buttom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        $this->add_responsive_control(
            'animation_right',
            [
                'label' => esc_html__('Right', 'cleanu-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .apartment-three__shape-1' => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        $this->add_responsive_control(
            'animation_left',
            [
                'label' => esc_html__('Left', 'cleanu-core'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 50,
                ],
                'selectors' => [
                    '{{WRAPPER}} .apartment-three__shape-1' => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        $this->add_control(
            'shape_tablet_position',
            [
                'label' => __('Tablet / Mobile Responsive', 'alipes-addon'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'alipes-addon'),
                'label_off' => __('Hide', 'alipes-addon'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'layout_type' => ['layout_one']
                ]
            ]
        );

        $this->end_controls_section();

        //General style
        $this->start_controls_section(
            'general_style',
            [
                'label' => esc_html__('Content Style', 'alipes-addon'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        include alipes_get_template('shape-one.php');
        include alipes_get_template('shape-two.php');
    }
}
