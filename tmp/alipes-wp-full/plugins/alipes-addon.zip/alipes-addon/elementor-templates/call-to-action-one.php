<?php if ('layout_one' == $settings['layout_type']) : ?>

	<!--Cta One Start-->
	<section class="cta-one">
		<div class="container">
			<div class="cta-one__inner">
				<div class="cta-one__shape-1 float-bob-y">
					<?php alipes_elementor_rendered_image($settings, 'shape_one'); ?>
				</div>
				<div class="cta-one__shape-2 img-bounce">
					<?php alipes_elementor_rendered_image($settings, 'shape_two'); ?>
				</div>
				<div class="cta-one__shape-3"></div>
				<div class="row">
					<div class="col-xl-5 col-lg-6">
						<div class="cta-one__left">
							<?php
							if (!empty($settings['title'])) :
								$this->add_inline_editing_attributes('title', 'none');
								alipes_elementor_rendered_content($this, 'title', 'cta-one__title', $settings['title_tag_layout_one']);
							endif;
							?>
							<div class="cta-one__btn-box">
								<?php
								if (!empty($settings['button_label'])) :
									alipes_basic_rendered_content($this, $settings,  'button_label', 'thm-btn cta-one__btn', 'a', 'button_url', '');
								endif;
								?>
							</div>
						</div>
					</div>
					<div class="col-xl-7 col-lg-6">
						<div class="cta-one__right">
							<?php
							if (!empty($settings['text'])) :
								alipes_basic_rendered_content($this, $settings,  'text', 'cta-one__text', 'p');
							endif;
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--Cta One End-->

<?php endif; ?>