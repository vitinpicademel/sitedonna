<?php if ('layout_one' == $settings['layout_type']) : ?>

  <div class="footer-widget__column footer-widget__newsletter">
    <?php if (!empty($settings['title'])) : ?>
      <div class="footer-widget__title-box">
        <?php
        if (!empty($settings['title'])) :
          $this->add_inline_editing_attributes('title', 'none');
          alipes_elementor_rendered_content($this, 'title', 'footer-widget__title', $settings['section_title_tag_layout_one']);
        endif;
        ?>
      </div>
    <?php endif; ?>
    <form class="footer-widget__email-box mc-form" data-url="<?php echo esc_html($settings['mailchimp_url']); ?>">
      <div class="footer-widget__email-input-box">
        <input type="email" placeholder="<?php echo esc_attr($settings['mc_input_placeholder']); ?>" name="email">
      </div>
      <button type="submit" class="footer-widget__subscribe-btn thm-btn"><?php echo esc_html($settings['btn_label']); ?></button>
    </form>
    <div class="mc-form__response"></div>
  </div>

<?php endif; ?>