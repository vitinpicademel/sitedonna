<?php if ('layout_one' === $settings['layout_type']) : ?>
    <!--Testimonial One Start-->
    <section class="testimonial-one">
        <div class="testimonial-one__bg" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']); ?>);"></div>
        <div class="testimonial-one__shape-2 float-bob-x">
            <?php alipes_elementor_rendered_image($settings, 'bg_shape_one'); ?>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-5">
                    <div class="testimonial-one__left">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['sec_sub_title'])) :
                                $this->add_inline_editing_attributes('sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                            endif;

                            if (!empty($settings['sec_title'])) :
                                $this->add_inline_editing_attributes('sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                            endif;
                            ?>
                        </div>
                        <div class="testimonial-one__reviews-box">
                            <?php
                            if (!empty($settings['sec_content'])) :
                                alipes_basic_rendered_content($this, $settings,  'sec_content', '', 'p');
                            endif;
                            ?>
                            <div class="testimonial-one__reviews">
                                <?php for ($i = 0; $i < $settings['sec_avg_rating']['size']; $i++) : ?>
                                    <span class="fa fa-star"></span>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7">
                    <div class="testimonial-one__right">
                        <div class="testimonial-one__img-2 zoom-fade">
                            <?php alipes_elementor_rendered_image($settings, 'bg_shape_two'); ?>
                        </div>
                        <div class="testimonial-one__img-2 testimonial-one__img-3 banner-3-Shake">
                            <?php alipes_elementor_rendered_image($settings, 'bg_shape_three'); ?>
                        </div>
                        <div class="testimonial-one__img-2 testimonial-one__img-4 zoominout-2">
                            <?php alipes_elementor_rendered_image($settings, 'bg_shape_four'); ?>
                        </div>
                        <div class="testimonial-one__img-2 testimonial-one__img-5 zoom-fade">
                            <?php alipes_elementor_rendered_image($settings, 'bg_shape_five'); ?>
                        </div>
                        <div class="testimonial-one__img-2 testimonial-one__img-6 banner-3-Shake">
                            <?php alipes_elementor_rendered_image($settings, 'bg_shape_six'); ?>
                        </div>
                        <div class="testimonial-one__carousel thm-owl__carousel owl-theme owl-carousel" data-owl-options='<?php echo esc_attr(alipes_get_owl_options($settings)); ?>'>
                            <?php foreach ($settings['testimonials'] as $index => $item) :  ?>
                                <!--Testimonial One Single Start-->
                                <div class="item">
                                    <div class="testimonial-one__single">
                                        <div class="testimonial-one__img-box">
                                            <?php if (!empty($item['image']['url'])) : ?>
                                                <div class="testimonial-one__img">
                                                    <?php alipes_elementor_rendered_image($item, 'image'); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="testimonial-one__single-inner">
                                            <?php if (!empty($item['shape']['url'])) : ?>
                                                <div class="testimonial-one__shape-1 float-bob-x">
                                                    <?php alipes_elementor_rendered_image($item, 'shape'); ?>
                                                </div>
                                            <?php endif; ?>
                                            <div class="testimonial-one__client-info">
                                                <div class="testimonial-one__rating">
                                                    <?php for ($i = 0; $i < $item['rating']['size']; $i++) : ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php endfor; ?>
                                                </div>

                                                <?php
                                                if (!empty($item['name'])) :
                                                    alipes_basic_rendered_content($this, $item,  'name', 'testimonial-one__client-name', 'h3');
                                                endif;

                                                if (!empty($item['designation'])) :
                                                    alipes_basic_rendered_content($this, $item,  'designation', 'testimonial-one__client-title', 'p');
                                                endif;
                                                ?>

                                                <div class="testimonial-one__quote">
                                                    <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                                </div>
                                            </div>
                                            <?php
                                            if (!empty($item['testimonial'])) :
                                                alipes_basic_rendered_content($this, $item,  'testimonial', 'testimonial-one__text', 'p');
                                            endif;
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <!--Testimonial One Single End-->
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Testimonial One Start-->
<?php endif; ?>