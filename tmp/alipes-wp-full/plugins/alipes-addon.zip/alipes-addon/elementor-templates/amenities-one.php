<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Amenities Start-->
    <section class="amenities">
        <?php if (!empty($settings['layout_one_bg_shape']['url'])) : ?>
            <div class="amenities__shape-1 img-bounce">
                <?php alipes_elementor_rendered_image($settings, 'layout_one_bg_shape'); ?>
            </div>
        <?php endif; ?>
        <div class="container">
            <div class="section-title text-center">
                <?php
                if (!empty($settings['sec_sub_title'])) :
                    $this->add_inline_editing_attributes('sec_sub_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                endif;

                if (!empty($settings['sec_title'])) :
                    $this->add_inline_editing_attributes('sec_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                endif;
                ?>
            </div>
            <div class="row">
                <?php
                $i = 1;
                foreach ($settings['amenities_list'] as $index => $item) :
                ?>
                    <!--Amenities Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="<?php echo esc_attr($i); ?>00ms">
                        <div class="amenities__single">
                            <div class="amenities__icon">
                                <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                            </div>
                            <<?php echo esc_attr($item['amenities_title_tag_layout_one']); ?> class="amenities__title">
                                <?php
                                if (!empty($item['title'])) :
                                    alipes_basic_rendered_content($this, $item,  'title', '', 'a');
                                endif;
                                ?>
                            </<?php echo esc_attr($item['amenities_title_tag_layout_one']); ?>>
                            <?php
                            if (!empty($item['subtitle'])) :
                                alipes_basic_rendered_content($this, $item,  'subtitle', 'amenities__text', 'p');
                            endif;
                            ?>
                            <?php
                            if (!empty($item['button_label'])) :
                                alipes_basic_rendered_content($this, $item,  'button_label', 'thm-btn amenities__btn', 'a', 'url', '');
                            endif;
                            ?>
                        </div>
                    </div>
                    <!--Amenities Single End-->
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!--Amenities End-->

<?php endif; ?>