<?php if ('layout_two' == $settings['layout_type']) : ?>
    <div class="accrodion-grp faq-one-accrodion" data-grp-name="faq-one-accrodion">
        <?php
        foreach ($settings['layout_two_faq_lists'] as $index => $item) :
        ?>
            <div class="accrodion <?php echo esc_attr(('yes' == $item['active_status'] ? 'active' : '')); ?>">
                <div class="accrodion-title">
                    <?php
                    if (!empty($item['question'])) :
                        alipes_basic_rendered_content($this, $item,  'question', '', 'h4');
                    endif;
                    ?>
                </div>
                <div class="accrodion-content">
                    <div class="inner">
                        <?php
                        if (!empty($item['answer'])) :
                            alipes_basic_rendered_content($this, $item,  'answer', '', 'p');
                        endif;
                        ?>
                    </div><!-- /.inner -->
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>