<?php if ('layout_one' === $settings['layout_type']) : ?>
    <div class="apartment-three__shape-1 img-bounce <?php if ($settings['shape_tablet_position'] != 'yes') : echo esc_attr("d-lg-block d-none");
                                                    endif; ?>">
        <?php alipes_elementor_rendered_image($settings, 'shape_one'); ?>
    </div>
<?php endif; ?>