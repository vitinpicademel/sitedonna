<?php if ('layout_one' == $settings['layout_type']) : ?>
    <div class="footer-widget__column footer-widget__contact">
        <?php if (!empty($settings['title'])) : ?>
            <div class="footer-widget__title-box">
                <?php
                if (!empty($settings['title'])) :
                    $this->add_inline_editing_attributes('title', 'none');
                    alipes_elementor_rendered_content($this, 'title', 'footer-widget__title', $settings['section_title_tag_layout_one']);
                endif;
                ?>
            </div>
        <?php endif; ?>
        <?php
        if (!empty($settings['text'])) :
            alipes_basic_rendered_content($this, $settings,  'text', 'footer-widget__contact-text', 'p');
        endif;
        ?>

        <ul class="footer-widget__contact-list list-unstyled ml-0">
            <?php
            foreach ($settings['footer_contact_list'] as $index => $item) :
            ?>
                <li>
                    <div class="icon">
                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ''], 'span'); ?>
                    </div>
                    <div class="text">
                        <p><a href="<?php echo esc_url($item['url']['url']); ?>"><?php echo esc_html($item['title']); ?></a></p>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>