<?php if ('layout_one' == $settings['layout_type']) : ?>

	<!--About One Start-->
	<section class="about-one">
		<?php if ($settings['bg_image_one']['url']) : ?>
			<div class="about-one__img-two">
				<?php alipes_elementor_rendered_image($settings, 'bg_image_one'); ?>
			</div>
		<?php endif; ?>
		<div class="container">
			<div class="row">
				<div class="col-xl-6">
					<div class="about-one__left">
						<div class="about-one__img-box wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
							<?php if ($settings['bg_image_two']['url']) : ?>
								<div class="about-one__img">
									<?php alipes_elementor_rendered_image($settings, 'bg_image_two'); ?>
								</div>
							<?php endif; ?>
							<?php if ($settings['bg_shape_one']['url']) : ?>
								<div class="about-one__shape-1 shape-mover">
									<?php alipes_elementor_rendered_image($settings, 'bg_shape_one'); ?>
								</div>
							<?php endif; ?>
							<div class="about-one__big-text">
								<?php
								if (!empty($settings['big_text'])) :
									alipes_basic_rendered_content($this, $settings,  'big_text', '', 'p');
								endif;
								?>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-6">
					<div class="about-one__right">
						<div class="section-title text-left">
							<?php
							if (!empty($settings['sec_sub_title'])) :
								$this->add_inline_editing_attributes('sec_sub_title', 'none');
								alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
							endif;

							if (!empty($settings['sec_title'])) :
								$this->add_inline_editing_attributes('sec_title', 'none');
								alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
							endif;
							?>
						</div>
						<?php

						if (!empty($settings['highlighted_text'])) :
							alipes_basic_rendered_content($this, $settings,  'highlighted_text', 'about-one__text-1', 'p');
						endif;

						if (!empty($settings['summary'])) :
							alipes_basic_rendered_content($this, $settings,  'summary', 'about-one__text-2', 'p');
						endif;

						?>

						<ul class="about-one__points-list list-unstyled ml-0">
							<?php foreach ($settings['layout_one_check_list'] as $index => $item) : ?>
								<li>
									<div class="about-one__points-list-content">
										<div class="icon">
											<?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
										</div>
										<div class="text">
											<?php
											if (!empty($item['title'])) :
												alipes_basic_rendered_content($this, $item,  'title', '', 'h3');
											endif;
											?>
										</div>
									</div>
									<?php
									if (!empty($item['content'])) :
										alipes_basic_rendered_content($this, $item,  'content', 'about-one__points-text', 'p');
									endif;
									?>
								</li>
							<?php endforeach; ?>
						</ul>
						<div class="about-one__btn-box">
							<?php if ($settings['bg_shape_two']['url']) : ?>
								<div class="about-one__shape-2 float-bob-x">
									<?php alipes_elementor_rendered_image($settings, 'bg_shape_two'); ?>
								</div>
							<?php endif; ?>
							<?php
							if (!empty($settings['button_label'])) :
								alipes_basic_rendered_content($this, $settings,  'button_label', 'about-one__btn thm-btn', 'a', 'button_url', '');
							endif;
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--About One Start-->

<?php endif; ?>