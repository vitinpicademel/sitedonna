<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Why Choose One Start-->
    <section class="why-choose-one">
        <div class="why-choose-one__bg" data-jarallax data-speed="0.2" data-imgPosition="50% 0%" style="background-image: url(<?php echo esc_url($settings['choose_bg_image_one']['url']); ?>);"></div>
        <?php if (!empty($settings['choose_bg_image_two']['url'])) : ?>
            <div class="why-choose-one__shape-2 wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                <?php alipes_elementor_rendered_image($settings, 'choose_bg_image_two'); ?>
            </div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="why-choose-one__left">
                        <div class="why-choose-one__inner">
                            <div class="why-choose-one__video-link">
                                <?php if (!empty($settings['video_url']['url'])) : ?>
                                    <a href="<?php echo esc_url($settings['video_url']['url']); ?>" class="video-popup">
                                        <div class="why-choose-one__video-icon">
                                            <span class="fa fa-play"></span>
                                            <i class="ripple"></i>
                                        </div>
                                    </a>
                                <?php endif; ?>
                                <?php if (!empty($settings['choose_bg_shape_one']['url'])) : ?>
                                    <div class="why-choose-one__shape-1 float-bob-x">
                                        <?php alipes_elementor_rendered_image($settings, 'choose_bg_shape_one'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php

                            if (!empty($settings['sec_title'])) :
                                $this->add_inline_editing_attributes('sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'sec_title', 'why-choose-one__title', $settings['section_title_tag_layout_one']);
                            endif;

                            ?>

                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="why-choose-one__right">
                        <div class="why-choose-one__points-box">
                            <?php if (is_array($settings['check_list_one'])) : ?>
                                <ul class="why-choose-one__points-list list-unstyled ml-0">
                                    <?php
                                    foreach ($settings['check_list_one'] as $index => $item) :
                                    ?>
                                        <li>
                                            <div class="icon">
                                                <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                            </div>
                                            <div class="text">
                                                <?php
                                                if (!empty($item['title'])) :
                                                    alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                                endif;
                                                ?>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <?php if (is_array($settings['check_list_two'])) : ?>
                                <ul class="why-choose-one__points-list why-choose-one__points-list-2 list-unstyled">
                                    <?php
                                    foreach ($settings['check_list_two'] as $index => $item) :
                                    ?>
                                        <li>
                                            <div class="icon">
                                                <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                            </div>
                                            <div class="text">
                                                <?php
                                                if (!empty($item['title'])) :
                                                    alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                                endif;
                                                ?>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Why Choose One Start-->

<?php endif; ?>