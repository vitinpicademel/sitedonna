<?php if ('layout_one' == $settings['layout_type']) : ?>
    <div class="site-footer__bottom">
        <div class="site-footer__bottom-inner">
            <div class="site-footer__bottom-left">
                <p class="site-footer__bottom-text">
                    <?php echo wp_kses($settings['title'], 'alipes_allowed_tags'); ?>
                </p>
            </div>
            <div class="site-footer__bottom-right">
                <div class="site-footer__social">
                    <?php foreach ($settings['social_icons'] as $item) : ?>
                        <a <?php echo esc_attr(!empty($item['social_url']['is_external']) ? 'target=_blank' : ' '); ?> href="<?php echo esc_url($item['social_url']['url']); ?>"><?php \Elementor\Icons_Manager::render_icon($item['social_icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>