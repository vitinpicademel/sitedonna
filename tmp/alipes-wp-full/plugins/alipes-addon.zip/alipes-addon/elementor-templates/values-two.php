<?php if ('layout_two' === $settings['layout_type']) : ?>
    <!--Values Two Start-->
    <section class="values-two">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="values-two__left">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['layout_two_sec_sub_title'])) :
                                $this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
                            endif;

                            if (!empty($settings['layout_two_sec_title'])) :
                                $this->add_inline_editing_attributes('layout_two_sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
                            endif;
                            ?>
                        </div>
                        <?php
                        if (!empty($settings['layout_two_sec_summary'])) :
                            alipes_basic_rendered_content($this, $settings,  'layout_two_sec_summary', 'values-two__text-1', 'p');
                        endif;
                        ?>
                        <div class="values-two__points-box">

                            <ul class="list-unstyled values-two__points ml-0">
                                <?php foreach ($settings['layout_two_values_list_one'] as  $item) : ?>
                                    <li>
                                        <div class="icon">
                                            <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
                                        </div>
                                        <div class="text">
                                            <?php
                                            if (!empty($item['title'])) :
                                                alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                            endif;
                                            ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>

                            <ul class="list-unstyled values-two__points values-two__points-two ml-0">
                                <?php foreach ($settings['layout_two_values_list_two'] as  $item) : ?>
                                    <li>
                                        <div class="icon">
                                            <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
                                        </div>
                                        <div class="text">
                                            <?php
                                            if (!empty($item['title'])) :
                                                alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                            endif;
                                            ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>

                            <ul class="list-unstyled values-two__points values-two__points-three ml-0">
                                <?php foreach ($settings['layout_two_values_list_three'] as  $item) : ?>
                                    <li>
                                        <div class="icon">
                                            <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
                                        </div>
                                        <div class="text">
                                            <?php
                                            if (!empty($item['title'])) :
                                                alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                            endif;
                                            ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="values-two__right">
                        <div class="values-two__img">
                            <?php alipes_elementor_rendered_image($settings, 'layout_two_background_image_one'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Values Two End-->
<?php endif; ?>