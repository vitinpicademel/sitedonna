<?php if ('layout_one' == $settings['layout_type']) : ?>
    <ul class="list-unstyled apartment-details-one__points ml-0">
        <?php
        foreach ($settings['layout_one_apartment_detail_check_list'] as $index => $item) :
        ?>
            <li>
                <div class="icon">
                    <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
                </div>
                <div class="text">
                    <?php
                    if (!empty($item['title'])) :
                        alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                    endif;
                    ?>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>