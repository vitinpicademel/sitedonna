<?php if ('layout_one' == $settings['layout_type']) : ?>
	<!--Team One Start-->
	<section class="team-one">
		<div class="container">
			<?php if (!empty($settings['sec_sub_title'] || $settings['sec_title'])) : ?>
				<div class="section-title text-center">
					<?php
					if (!empty($settings['sec_sub_title'])) :
						$this->add_inline_editing_attributes('sec_sub_title', 'none');
						alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
					endif;

					if (!empty($settings['sec_title'])) :
						$this->add_inline_editing_attributes('sec_title', 'none');
						alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
					endif;
					?>
				</div>
			<?php endif; ?>
			<div class="row">
				<?php foreach ($settings['team_items'] as $index => $item) : ?>
					<!--Team One Single Start-->
					<div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="<?php echo esc_attr($index + 1); ?>00ms">
						<div class="team-one__single">
							<div class="team-one__img-box">
								<div class="team-one__img">
									<?php alipes_elementor_rendered_image($item, 'image'); ?>
								</div>
								<ul class="list-unstyled team-one__social-two">
									<li><a href="#"><i class="fas fa-share-alt"></i></a></li>
								</ul>
								<ul class="list-unstyled team-one__social">
									<?php echo wp_kses($item['social_network'], 'alipes_allowed_tags'); ?>
								</ul>
							</div>
							<div class="team-one__content">
								<<?php echo esc_attr($item['team_name_tag_layout_one']); ?> class="team-one__name">
									<?php
									if (!empty($item['name'])) :
										alipes_basic_rendered_content($this, $item,  'name', '', 'a');
									endif;
									?>
								</<?php echo esc_attr($item['team_name_tag_layout_one']); ?>>
								<?php
								if (!empty($item['designation'])) :
									alipes_basic_rendered_content($this, $item,  'designation', 'team-one__sub-title', $item['team_designation_tag_layout_one']);
								endif;
								?>
							</div>
						</div>
					</div>
					<!--Team One Single End-->
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<!--Team One End-->




<?php endif; ?>