<?php if ('layout_one' == $settings['layout_type']) : ?>
    <div class="footer-widget__column footer-widget__about">
        <div class="footer-widget__logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($settings['logo']['url']); ?>" width="<?php echo esc_attr($settings['logo_dimension']['width']); ?>" height="<?php echo esc_attr($settings['logo_dimension']['height']); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>">
            </a>
        </div>
        <div class="footer-widget__about-text-box">
            <?php
            if (!empty($settings['text'])) :
                alipes_basic_rendered_content($this, $settings,  'text', 'footer-widget__about-text', 'p');
            endif;
            ?>
        </div>
    </div>
<?php endif; ?>