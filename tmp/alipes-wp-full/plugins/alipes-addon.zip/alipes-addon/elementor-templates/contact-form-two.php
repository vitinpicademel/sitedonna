<?php if ('layout_two' == $settings['layout_type']) : ?>
	<!--Contact Two Start-->
	<section class="contact-page">
		<div class="container">
			<div class="section-title text-center">
				<?php
				if (!empty($settings['layout_two_sec_sub_title'])) :
					$this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
					alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
				endif;

				if (!empty($settings['layout_two_sec_title'])) :
					$this->add_inline_editing_attributes('layout_two_sec_title', 'none');
					alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
				endif;
				?>
			</div>
			<div class="contact-page__inner">
				<?php echo str_replace("<br />", "", trim(do_shortcode('[contact-form-7 id="' . $settings['layout_two_select_wpcf7_form'] . '" ]'))); ?>
			</div>
		</div>
	</section>
	<!--Contact Two End-->
<?php endif; ?>