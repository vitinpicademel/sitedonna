<?php if ('layout_one' == $settings['layout_type']) : ?>

    <!--Brand One Start-->
    <section class="brand-one">
        <div class="brand-one__wrap">
            <?php if ($settings['bg_shape_one']['url']) : ?>
                <div class="brand-one__shape-1 float-bob-y">
                    <?php alipes_elementor_rendered_image($settings, 'bg_shape_one') ?>
                </div>
            <?php endif; ?>
            <?php if ($settings['bg_shape_two']['url']) : ?>
                <div class="brand-one__shape-2 float-bob-x">
                    <?php alipes_elementor_rendered_image($settings, 'bg_shape_two') ?>
                </div>
            <?php endif; ?>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="brand-one__inner">
                            <div class="thm-swiper__slider swiper-container" data-swiper-options='<?php echo esc_attr(alipes_get_swiper_options($settings)); ?>'>
                                <div class="swiper-wrapper">
                                    <?php foreach ($settings['sponsor_images'] as $image) : ?>
                                        <div class="swiper-slide">
                                            <?php alipes_elementor_rendered_image($image, 'image') ?>
                                        </div><!-- /.swiper-slide -->
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Brand One End-->
<?php endif; ?>