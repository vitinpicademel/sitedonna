<?php if ('layout_two' == $settings['layout_type']) : ?>
	<!--About Two Start-->
	<section class="about-two">
		<div class="about-two__shape-3 float-bob-x">
			<?php alipes_elementor_rendered_image($settings, 'layout_two_bg_shape_three'); ?>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-xl-5 col-lg-6">
					<div class="about-two__left">
						<div class="section-title text-left">
							<?php
							if (!empty($settings['layout_two_sec_sub_title'])) :
								$this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
								alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
							endif;

							if (!empty($settings['layout_two_sec_title'])) :
								$this->add_inline_editing_attributes('layout_two_sec_title', 'none');
								alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
							endif;
							?>
						</div>
						<?php
						if (!empty($settings['layout_two_summary'])) :
							alipes_basic_rendered_content($this, $settings,  'layout_two_summary', 'about-two__text-1', 'p');
						endif;
						?>
						<ul class="about-two__points-list list-unstyled ml-0">
							<?php foreach ($settings['layout_two_features_list'] as $index => $item) : ?>
								<li>
									<div class="icon">
										<?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
									</div>
									<?php if (!empty($item['title'])) : ?>
										<div class="text">
											<?php
											if (!empty($item['title'])) :
												alipes_basic_rendered_content($this, $item,  'title', '', 'p');
											endif;
											?>
										</div>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
						<div class="about-two__btn-box">
							<?php
							if (!empty($settings['layout_two_button_label'])) :
								alipes_basic_rendered_content($this, $settings,  'layout_two_button_label', 'thm-btn about-two__btn', 'a', 'layout_two_button_url', '');
							endif;
							?>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-6">
					<div class="about-two__middle">
						<div class="about-two__img">
							<?php alipes_elementor_rendered_image($settings, 'layout_two_image'); ?>
							<div class="about-two__shape-2">
								<?php alipes_elementor_rendered_image($settings, 'layout_two_bg_shape_two'); ?>
							</div>
							<div class="about-two__year">
								<div class="about-two__shape-1">
									<?php alipes_elementor_rendered_image($settings, 'layout_two_bg_shape_one'); ?>
								</div>
								<?php
								if (!empty($settings['layout_two_year'])) :
									alipes_basic_rendered_content($this, $settings,  'layout_two_year', '', 'h3');
								endif;
								?>
								<?php
								if (!empty($settings['layout_two_year_title'])) :
									alipes_basic_rendered_content($this, $settings,  'layout_two_year_title', '', 'p');
								endif;
								?>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-4">
					<div class="about-two__right">
						<?php if (is_array($settings['layout_two_counter_list'])) : ?>
							<ul class="about-two__counter list-unstyled ml-0">
								<?php foreach ($settings['layout_two_counter_list'] as $index => $item) : ?>
									<li>
										<div class="about-two__count-box">
											<<?php echo esc_attr($item['about_counter_number_tag_layout_two']); ?> class="odometer" data-count="<?php echo esc_attr($item['number']); ?>">00</<?php echo esc_attr($item['about_counter_number_tag_layout_two']); ?>>
											<?php
											if (!empty($item['title'])) :
												alipes_basic_rendered_content($this, $item,  'title', 'about-two__text', 'p');
											endif;
											?>
										</div>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--About Two End-->
<?php endif; ?>