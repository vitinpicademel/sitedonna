<?php if ('layout_two' === $settings['layout_type']) : ?>
	<!--Main Slider Two Start-->
	<section class="main-slider-two clearfix">
		<div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": <?php echo esc_attr($settings['items']['size']); ?>,
				"loop": <?php echo esc_attr(('yes' == $settings['loop']) ? 'true' : 'false'); ?>,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": <?php echo esc_attr($settings['delay']['size']); ?>
                }}'>
			<div class="swiper-wrapper">
				<?php foreach ($settings['layout_two_sliders'] as $slider) : ?>
					<div class="swiper-slide">
						<div class="image-layer-two" style="background-image: url(<?php echo esc_url($slider['background_image']['url']); ?>);"></div>
						<!-- /.image-layer -->
						<div class="main-slider-two__shape-1">
							<?php alipes_elementor_rendered_image($slider, 'shape_one'); ?>
						</div>
						<div class="main-slider-two__shape-2">
							<?php alipes_elementor_rendered_image($slider, 'shape_two'); ?>
						</div>
						<div class="container">
							<div class="row">
								<div class="col-xl-12">
									<div class="main-slider-two__content">
										<?php
										if (!empty($slider['title'])) :
											alipes_basic_rendered_content($this, $slider,  'title', 'main-slider-two__title', $slider['title_tag_layout_two']);
										endif;

										if (!empty($slider['sub_title'])) :
											alipes_basic_rendered_content($this, $slider,  'sub_title', 'main-slider-two__text', $slider['sub_title_tag_layout_two']);
										endif;
										?>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<?php if ('yes' == $settings['enable_dots']) : ?>
				<!-- If we need navigation buttons -->
				<div class="swiper-pagination" id="main-slider-pagination"></div>
			<?php endif; ?>
		</div>
	</section>
	<!--Main Slider Two End-->
<?php endif; ?>