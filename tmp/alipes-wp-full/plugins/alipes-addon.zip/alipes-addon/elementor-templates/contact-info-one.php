<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Location Start-->
    <section class="location">
        <?php if (!empty($settings['bg_shape_one']['url'])) : ?>
            <div class="location-shape-1 float-bob-x">
                <?php alipes_elementor_rendered_image($settings, 'bg_shape_one'); ?>
            </div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <?php
                foreach ($settings['layout_one_items'] as $key => $item) :
                ?>
                    <!--Location single Start-->
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <div class="location__single">
                            <?php
                            if (!empty($item['title'])) :
                                alipes_basic_rendered_content($this, $item,  'title', 'location__title', $item['contact_location_title_tag_layout_one']);
                            endif;

                            if (!empty($item['subtitle'])) :
                                alipes_basic_rendered_content($this, $item,  'subtitle', 'location__text', 'p');
                            endif;
                            ?>
                            <div class="location__phone-email">
                                <?php echo wp_kses($item['content'], 'alipes_allowed_tags'); ?>
                            </div>
                        </div>
                    </div>
                    <!--Location single End-->
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!--Location End-->
<?php endif; ?>