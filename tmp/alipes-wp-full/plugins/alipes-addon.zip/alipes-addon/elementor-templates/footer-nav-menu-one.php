<?php if ('layout_one' == $settings['layout_type']) : ?>
    <div class="footer-widget__column footer-widget__explore">
        <?php if (!empty($settings['title'])) : ?>
            <div class="footer-widget__title-box">
                <?php
                if (!empty($settings['title'])) :
                    $this->add_inline_editing_attributes('title', 'none');
                    alipes_elementor_rendered_content($this, 'title', 'footer-widget__title', $settings['section_title_tag_layout_one']);
                endif;
                ?>
            </div>
        <?php endif; ?>
        <div class="footer-widget__explore-list-box">
            <?php
            foreach ($settings['nav_menus'] as $nav_menu) : ?>
                <?php wp_nav_menu(array(
                    'menu' => $nav_menu['nav_menu'],
                    'menu_class' => 'footer-widget__explore-list list-unstyled ml-0'
                ));
                ?>
            <?php endforeach; ?>
            <?php
            foreach ($settings['nav_menus_two'] as $nav_menu) : ?>
                <?php wp_nav_menu(array(
                    'menu' => $nav_menu['nav_menu_two'],
                    'menu_class' => 'footer-widget__explore-list list-unstyled ml-84'
                ));
                ?>
            <?php endforeach; ?>

        </div>
    </div>
<?php endif; ?>