<?php if ('layout_three' == $settings['layout_type']) : ?>
    <!--Contact Two Start-->
    <section class="contact-two">
        <div class="contact-two__shape-1" style="background-image: url(<?php echo esc_url($settings['layout_three_shape_one']['url']); ?>);"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-4">
                    <div class="contact-two__left">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['layout_three_sec_sub_title'])) :
                                $this->add_inline_editing_attributes('layout_three_sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_three_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_three']);
                            endif;

                            if (!empty($settings['layout_three_sec_title'])) :
                                $this->add_inline_editing_attributes('layout_three_sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_three_sec_title', 'section-title__title', $settings['section_title_tag_layout_three']);
                            endif;
                            ?>
                        </div>
                        <?php foreach ($settings['layout_three_contact_info'] as $index => $item) :  ?>
                            <div class="contact-two__call">
                                <div class="contact-two__call-icon">
                                    <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
                                </div>
                                <div class="contact-two__call-content">
                                    <p class="contact-two__number-email">
                                        <?php echo wp_kses($item['content'], 'ogenix_allowed_tags'); ?>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php
                        if (!empty($settings['layout_three_text'])) :
                            alipes_basic_rendered_content($this, $settings,  'layout_three_text', 'contact-two__text', 'p');
                        endif;
                        ?>
                    </div>
                </div>
                <div class="col-xl-8 col-lg-8">
                    <div class="contact-two__right">
                        <?php echo str_replace("<br />", "", trim(do_shortcode('[contact-form-7 id="' . $settings['layout_three_select_wpcf7_form'] . '" ]'))); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Contact Two End-->

<?php endif; ?>