<?php if ('layout_two' == $settings['layout_type']) : ?>
    <!--CTA Two Start-->
    <section class="cta-two">
        <div class="cta-two__bg" data-jarallax data-speed="0.2" data-imgPosition="50% 0%" style="background-image: url(<?php echo esc_url($settings['layout_two_bg_image']['url']); ?>);"></div>
        <div class="cta-two__inner">
            <?php
            if (!empty($settings['layout_two_title'])) :
                $this->add_inline_editing_attributes('layout_two_title', 'none');
                alipes_elementor_rendered_content($this, 'layout_two_title', 'cta-two__title', $settings['title_tag_layout_two']);
            endif; ?>
            <?php
            if (!empty($settings['layout_two_text'])) :
                $this->add_inline_editing_attributes('layout_two_text', 'none');
                alipes_elementor_rendered_content($this, 'layout_two_text', 'cta-two__text', 'p');
            endif; ?>
            <div class="cta-two__btn-box">
                <?php
                if (!empty($settings['layout_two_button_label'])) :
                    alipes_basic_rendered_content($this, $settings,  'layout_two_button_label', 'cta-two__btn thm-btn', 'a', 'layout_two_button_url', '');
                endif;
                ?>
            </div>
        </div>
    </section>
    <!--CTA Two End-->
<?php endif; ?>