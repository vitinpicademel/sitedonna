<?php if ('layout_three' === $settings['layout_type']) : ?>

	<!--Main Slider Three Start-->
	<section class="main-slider-three clearfix">
		<div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": <?php echo esc_attr($settings['items']['size']); ?>,
				"loop": <?php echo esc_attr(('yes' == $settings['loop']) ? 'true' : 'false'); ?>,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": <?php echo esc_attr($settings['delay']['size']); ?>
                }}'>
			<div class="swiper-wrapper">
				<?php foreach ($settings['layout_three_sliders'] as $slider) : ?>
					<div class="swiper-slide">
						<div class="image-layer-three" style="background-image: url(<?php echo esc_url($slider['background_image']['url']); ?>);"></div>
						<!-- /.image-layer -->
						<div class="main-slider-three__shape-1">
							<?php alipes_elementor_rendered_image($slider, 'shape'); ?>
						</div>
						<div class="container">
							<div class="row">
								<div class="col-xl-12">
									<div class="main-slider-three__content">
										<?php
										if (!empty($slider['title'])) :
											alipes_basic_rendered_content($this, $slider,  'title', 'main-slider-three__title', $slider['title_tag_layout_three']);
										endif;
										?>
										<div class="main-slider-three__details-box">
											<?php
											if (!empty($slider['sub_title'])) :
												alipes_basic_rendered_content($this, $slider,  'sub_title', 'main-slider-three__details-sub-title', $slider['sub_title_tag_layout_three']);
											endif;
											?>
											<div class="main-slider-three__details">
												<div class="main-slider-three__details-icon">
													<?php \Elementor\Icons_Manager::render_icon($slider['count_icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
												</div>
												<div class="main-slider-three__details-content">
													<h3 class="odometer" data-count="<?php echo esc_attr($slider['count_number']); ?>">00</h3>
													<?php
													if (!empty($slider['sub_title'])) :
														alipes_basic_rendered_content($this, $slider,  'count_text', 'main-slider-three__details-text', 'p');
													endif;
													?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<?php if ('yes' == $settings['enable_nav']) : ?>
				<!-- If we need navigation buttons -->
				<div class="main-slider-three__nav">
					<div class="swiper-button-prev" id="main-slider__swiper-button-next">
						<?php \Elementor\Icons_Manager::render_icon($settings['nav_left_icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
					</div>
					<div class="swiper-button-next" id="main-slider__swiper-button-prev">
						<?php \Elementor\Icons_Manager::render_icon($settings['nav_right_icon'], ['aria-hidden' => 'true', 'class' => ' '], 'i'); ?>
					</div>
				</div>
			<?php endif; ?>

		</div>
	</section>
	<!--Main Slider Three End-->

<?php endif; ?>