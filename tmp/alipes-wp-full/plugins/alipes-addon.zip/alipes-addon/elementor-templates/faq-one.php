<?php if ('layout_one' == $settings['layout_type']) : ?>

	<!--Faq Page Start-->
	<section class="faq-page">
		<div class="container">
			<div class="row">
				<div class="col-xl-6 col-lg-6">
					<div class="faq-page__single">
						<div class="accrodion-grp faq-one-accrodion" data-grp-name="faq-one-accrodion-1">
							<?php
							foreach ($settings['faq_lists'] as $index => $item) :
							?>
								<div class="accrodion <?php echo esc_attr(('yes' == $item['active_status'] ? 'active' : '')); ?>">
									<div class="accrodion-title">
										<<?php echo esc_attr($item['faq_one_question_tag_layout_one']); ?>>
											<span class="icon"></span>
											<?php echo esc_html($item['question']); ?>
										</<?php echo esc_attr($item['faq_one_question_tag_layout_one']); ?>>
									</div>
									<div class="accrodion-content">
										<div class="inner">
											<?php
											if (!empty($item['answer'])) :
												alipes_basic_rendered_content($this, $item,  'answer', '', 'p');
											endif;
											?>
										</div><!-- /.inner -->
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
				<div class="col-xl-6 col-lg-6">
					<div class="faq-page__single">
						<div class="accrodion-grp faq-one-accrodion" data-grp-name="faq-one-accrodion-2">
							<?php
							foreach ($settings['faq_two_lists'] as $index => $item) :
							?>
								<div class="accrodion <?php echo esc_attr(('yes' == $item['active_status'] ? 'active' : '')); ?>">
									<div class="accrodion-title">
										<<?php echo esc_attr($item['faq_two_question_tag_layout_one']); ?>>
											<span class="icon"></span>
											<?php echo esc_html($item['question']); ?>
										</<?php echo esc_attr($item['faq_two_question_tag_layout_one']); ?>>
									</div>
									<div class="accrodion-content">
										<div class="inner">
											<?php
											if (!empty($item['answer'])) :
												alipes_basic_rendered_content($this, $item,  'answer', '', 'p');
											endif;
											?>
										</div><!-- /.inner -->
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--Faq Page End-->

<?php endif; ?>