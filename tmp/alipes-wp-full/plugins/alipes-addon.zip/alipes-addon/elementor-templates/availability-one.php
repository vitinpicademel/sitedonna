<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Availability Start-->
    <section class="availability">
        <div class="availability__bg" style="background-image: url(<?php echo esc_url($settings['bac_image_one']['url']); ?>);">
        </div>
        <div class="container">
            <div class="section-title text-center">
                <?php
                if (!empty($settings['sec_sub_title'])) :
                    $this->add_inline_editing_attributes('sec_sub_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                endif;

                if (!empty($settings['sec_title'])) :
                    $this->add_inline_editing_attributes('sec_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                endif;
                ?>
            </div>
            <div class="avilability__table-responsive">
                <table class="table avilability__table">
                    <thead>
                        <?php
                        foreach ($settings['availability_title_list'] as $index => $item) :
                        ?>
                            <tr>
                                <th><?php echo esc_html($item['residance_title']); ?></th>
                                <th><?php echo esc_html($item['room_title']); ?></th>
                                <th><?php echo esc_html($item['bath_title']); ?></th>
                                <th><?php echo esc_html($item['sq_fit_title']); ?></th>
                                <th><?php echo esc_html($item['floor_title']); ?></th>
                                <th><?php echo esc_html($item['terrace_title']); ?></th>
                                <th><?php echo esc_html($item['plan_title']); ?></th>
                            </tr>
                        <?php endforeach; ?>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($settings['availability_content_list'] as $index => $item) :
                        ?>
                            <tr>
                                <td>
                                    <?php
                                    if (!empty($item['residance_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'residance_content', 'residence-name', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if (!empty($item['room_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'room_content', 'count', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if (!empty($item['bath_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'bath_content', 'count', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if (!empty($item['squre_fit_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'squre_fit_content', 'count', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if (!empty($item['floor_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'floor_content', 'count', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if (!empty($item['terrace_content'])) :
                                        alipes_basic_rendered_content($this, $item,  'terrace_content', 'count', 'p');
                                    endif;
                                    ?>
                                </td>
                                <td>
                                    <div class="avilability__btn-box">
                                        <?php
                                        if (!empty($item['button_label'])) :
                                            alipes_basic_rendered_content($this, $item,  'button_label', 'thm-btn avilability__btn', 'a');
                                        endif;
                                        ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <!--Availability End-->
<?php endif; ?>