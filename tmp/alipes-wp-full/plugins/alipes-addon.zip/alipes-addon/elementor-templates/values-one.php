<?php if ('layout_one' === $settings['layout_type']) : ?>
    <!--Values One Start-->
    <section class="values-one">
        <div class="values-one__wrap">
            <div class="values-one__left">
                <div class="values-one__bg" style="background-image: url(<?php echo esc_url($settings['background_image_one']['url']); ?>);">
                </div>
            </div>
            <div class="values-one__right">
                <?php if (!empty($settings['background_shape_one']['url'])) : ?>
                    <div class="values-one__shape-1 float-bob-x">
                        <?php alipes_elementor_rendered_image($settings, 'background_shape_one') ?>
                    </div>
                <?php endif; ?>
                <div class="values-one__content">
                    <div class="section-title text-left">
                        <?php
                        if (!empty($settings['sec_sub_title'])) :
                            $this->add_inline_editing_attributes('sec_sub_title', 'none');
                            alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                        endif;

                        if (!empty($settings['sec_title'])) :
                            $this->add_inline_editing_attributes('sec_title', 'none');
                            alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                        endif;
                        ?>
                    </div>
                    <?php
                    if (!empty($settings['sec_summary'])) :
                        alipes_basic_rendered_content($this, $settings,  'sec_summary', 'values-one__text', 'p');
                    endif;
                    ?>
                    <div class="values-one__points-box">
                        <?php if (!empty($settings['background_image_two']['url'])) : ?>
                            <div class="values-one__points-img">
                                <?php alipes_elementor_rendered_image($settings, 'background_image_two'); ?>
                            </div>
                        <?php endif; ?>
                        <ul class="values-one__points list-unstyled ml-0">
                            <?php foreach ($settings['layout_one_values_items'] as $index => $item) : ?>
                                <li>
                                    <div class="icon">
                                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                    </div>
                                    <div class="text">
                                        <?php
                                        if (!empty($item['title'])) :
                                            alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                        endif;
                                        ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Values One End-->
<?php endif; ?>