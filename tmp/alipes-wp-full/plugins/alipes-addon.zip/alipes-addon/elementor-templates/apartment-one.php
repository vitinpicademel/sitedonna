<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Apartment One Start-->
    <section class="apartment-one">
        <div class="apartment-one__bg" style="background-image: url(<?php echo esc_url($settings['layout_one_bg_shape']['url']); ?>);"></div>
        <div class="container">
            <div class="section-title text-center">
                <?php
                if (!empty($settings['sec_sub_title'])) :
                    $this->add_inline_editing_attributes('sec_sub_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                endif;

                if (!empty($settings['sec_title'])) :
                    $this->add_inline_editing_attributes('sec_title', 'none');
                    alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                endif;
                ?>
            </div>
            <?php if (is_array($settings['layout_one_apartment_list'])) : ?>
                <div class="row">
                    <?php
                    foreach ($settings['layout_one_apartment_list'] as $index => $item) :
                    ?>
                        <!--Apartment One Single Start-->
                        <div class="col-xl-3 col-lg-6 col-md-6">
                            <div class="apartment-one__single">
                                <div class="apartment-one__img-box">
                                    <div class="apartment-one__img">
                                        <?php alipes_elementor_rendered_image($item, 'image'); ?>
                                    </div>
                                    <div class="apartment-one__content">
                                        <div class="apartment-one__title-box">

                                            <<?php echo esc_attr($item['apartment_title_tag_layout_one']); ?> class="apartment-one__title">
                                                <?php
                                                if (!empty($item['title'])) :
                                                    alipes_basic_rendered_content($this, $item,  'title', '', 'a');
                                                endif;
                                                ?>
                                            </<?php echo esc_attr($item['apartment_title_tag_layout_one']); ?>>

                                        </div>
                                        <div class="apartment-one__arrow">
                                            <a href="<?php echo esc_url($item['url']['url']); ?>"> <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?></a>
                                        </div>

                                    </div>
                                    <div class="apartment-one__btn-box">
                                        <?php
                                        if (!empty($item['button_label'])) :
                                            alipes_basic_rendered_content($this, $item,  'button_label', 'thm-btn apartment-one__btn', 'a', 'url', '');
                                        endif;
                                        ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--Apartment One Single End-->
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <!--Apartment One Start-->
<?php endif; ?>