<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Gallery One Start-->
    <section class="gallery-one">
        <div class="container">
            <div class="gallery-one__carousel owl-carousel owl-theme thm-owl__carousel" data-owl-options='<?php echo esc_attr(alipes_get_owl_options($settings)); ?>'>
                <?php foreach ($settings['images'] as $index => $item) :  ?>
                    <!--Gallery One Single Start-->
                    <div class="item">
                        <div class="gallery-one__single">
                            <div class="gallery-one__img-box">
                                <div class="gallery-one__img">
                                    <?php alipes_elementor_rendered_image($item, 'image'); ?>
                                </div>
                                <div class="gallery-one__content">
                                    <?php
                                    if (!empty($item['subtitle'])) :
                                        alipes_basic_rendered_content($this, $item,  'subtitle', 'gallery-one__sub-title', 'p');
                                    endif;
                                    ?>
                                    <<?php echo esc_attr($item['gallery_title_tag_layout_one']); ?> class="gallery-one__title">
                                        <?php
                                        if (!empty($item['title'])) :
                                            alipes_basic_rendered_content($this, $item,  'title', '', 'a');
                                        endif;
                                        ?>
                                    </<?php echo esc_attr($item['gallery_title_tag_layout_one']); ?>>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Gallery One Single End-->
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!--Gallery One Start-->
<?php endif; ?>