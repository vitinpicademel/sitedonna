<?php if ('layout_two' == $settings['layout_type']) : ?>
    <!--Apartment Two Start-->
    <section class="apartment-two">
        <div class="container">
            <?php if (!empty($settings['layout_two_sec_sub_title'] || $settings['layout_two_sec_title'])) : ?>
                <div class="section-title text-center">
                    <?php
                    if (!empty($settings['layout_two_sec_sub_title'])) :
                        $this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
                        alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
                    endif;
                    ?>

                    <?php
                    if (!empty($settings['layout_two_sec_title'])) :
                        $this->add_inline_editing_attributes('layout_two_sec_title', 'none');
                        alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
                    endif;
                    ?>
                </div>
            <?php endif; ?>
            <div class="row">
                <?php
                $i = 1;
                foreach ($settings['layout_two_apartment_list'] as $index => $item) :
                ?>
                    <!--Apartment Two Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="<?php echo esc_attr($i); ?>00ms">
                        <div class="apartment-two__single">
                            <div class="apartment-two__img">
                                <?php alipes_elementor_rendered_image($item, 'image'); ?>
                                <div class="apartment-two__btn-box">
                                    <?php
                                    if (!empty($item['button_label'])) :
                                        alipes_basic_rendered_content($this, $item,  'button_label', 'thm-btn apartment-two__btn', 'a', 'url', '');
                                    endif;
                                    ?>
                                </div>
                            </div>
                            <div class="apartment-two__content">
                                <<?php echo esc_attr($item['apartment_title_tag_layout_two']); ?> class="apartment-two__title">
                                    <?php
                                    if (!empty($item['title'])) :
                                        alipes_basic_rendered_content($this, $item,  'title', '', 'a');
                                    endif;
                                    ?>
                                </<?php echo esc_attr($item['apartment_title_tag_layout_two']); ?>>

                                <?php
                                if (!empty($item['subtitle'])) :
                                    alipes_basic_rendered_content($this, $item,  'subtitle', 'apartment-two__sub-title', 'p');
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                    <!--Apartment Two Single End-->
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!--Apartment Two End-->
<?php endif; ?>