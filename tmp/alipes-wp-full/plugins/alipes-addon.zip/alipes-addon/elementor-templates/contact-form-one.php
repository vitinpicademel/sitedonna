<?php if ('layout_one' == $settings['layout_type']) : ?>

	<!--Contact One Start-->
	<section class="contact-one">
		<div class="container">
			<div class="row">
				<div class="col-xl-7 col-lg-8">
					<div class="contact-one__left">
						<div class="section-title text-left">
							<?php
							if (!empty($settings['sec_sub_title'])) :
								$this->add_inline_editing_attributes('sec_sub_title', 'none');
								alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
							endif;

							if (!empty($settings['sec_title'])) :
								$this->add_inline_editing_attributes('sec_title', 'none');
								alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
							endif;
							?>
						</div>
						<div class="contact-one__person">
							<div class="contact-one__person-info">
								<?php if (!empty($settings['con_person_image']['url'])) : ?>
									<div class="contact-one__person-img">
										<?php alipes_elementor_rendered_image($settings, 'con_person_image'); ?>
									</div>
								<?php endif; ?>
								<div class="contact-one__person-content">
									<?php
									if (!empty($settings['con_person_name'])) :
										$this->add_inline_editing_attributes('con_person_name', 'none');
										alipes_elementor_rendered_content($this, 'con_person_name', 'contact-one__person-name', $settings['contact_person_name_tag_layout_one']);
									endif;
									?>
									<?php
									if (!empty($settings['con_person_title'])) :
										alipes_basic_rendered_content($this, $settings,  'con_person_title', 'contact-one__person-sub-title', 'p');
									endif;
									?>
								</div>
							</div>
							<div class="contact-one__person-text">
								<?php
								if (!empty($settings['con_person_content'])) :
									alipes_basic_rendered_content($this, $settings,  'con_person_content', '', 'p');
								endif;
								?>
							</div>
						</div>
						<ul class="contact-one__points list-unstyled ml-0">
							<?php foreach ($settings['layout_one_contact_info'] as $index => $item) :  ?>
								<li>
									<div class="icon">
										<?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
									</div>
									<div class="content">
										<?php
										if (!empty($item['title'])) :
											alipes_basic_rendered_content($this, $item,  'title', '', 'p');
										endif;
										?>
										<<?php echo esc_attr($item['contact_info_tag_layout_one']); ?>>
											<?php echo wp_kses($item['content'], 'ogenix_allowed_tags'); ?>
										</<?php echo esc_attr($item['contact_info_tag_layout_one']); ?>>
									</div>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div>
				<div class="col-xl-5 col-lg-4">
					<div class="contact-one__right">
						<div class="contact-one__form-box wow slideInRight" data-wow-delay="100ms" data-wow-duration="2500ms">
							<div class="contact-form-bg" style="background-image: url(<?php echo esc_url($settings['bg_shape']['url']); ?>);">
							</div>
							<div class="section-title text-left">
								<?php
								if (!empty($settings['con_form_sub_title'])) :
									$this->add_inline_editing_attributes('con_form_sub_title', 'none');
									alipes_elementor_rendered_content($this, 'con_form_sub_title', 'section-title__tagline', $settings['contact_form_sub_title_tag_layout_one']);
								endif;

								if (!empty($settings['con_form_title'])) :
									$this->add_inline_editing_attributes('con_form_title', 'none');
									alipes_elementor_rendered_content($this, 'con_form_title', 'section-title__title', $settings['contact_form_title_tag_layout_one']);
								endif;
								?>
							</div>
							<?php echo str_replace("<br />", "", trim(do_shortcode('[contact-form-7 id="' . $settings['select_wpcf7_form'] . '" ]'))); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--Contact One Start-->

<?php endif; ?>