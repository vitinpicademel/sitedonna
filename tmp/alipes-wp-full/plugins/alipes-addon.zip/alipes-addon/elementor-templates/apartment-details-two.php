<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Apartment Details Two Start-->
    <section class="apartment-details-two">
        <?php if (!empty($settings['bg_shape_one']['url'])) : ?>
            <div class="apartment-details-two__shape-2">
                <?php alipes_elementor_rendered_image($settings, 'bg_shape_one') ?>
            </div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6">
                    <div class="apartment-details-two__left">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['sec_sub_title'])) :
                                $this->add_inline_editing_attributes('sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_one']);
                            endif;

                            if (!empty($settings['sec_title'])) :
                                $this->add_inline_editing_attributes('sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'sec_title', 'section-title__title', $settings['section_title_tag_layout_one']);
                            endif;
                            ?>
                        </div>
                        <div class="apartment-details-two__btn-box">
                            <?php
                            if (!empty($settings['button_label'])) :
                                alipes_basic_rendered_content($this, $settings,  'button_label', 'thm-btn apartmthree__btn', 'a', 'button_url', '');
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-6">
                    <div class="apartment-details-two__right">
                        <?php if (!empty($settings['bg_image_one']['url'])) : ?>
                            <div class="apartment-details-two__img zoom-fade-2">
                                <?php alipes_elementor_rendered_image($settings, 'bg_image_one') ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Apartment Details Two End-->
<?php endif; ?>