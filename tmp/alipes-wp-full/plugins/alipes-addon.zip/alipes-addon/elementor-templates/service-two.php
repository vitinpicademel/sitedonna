<?php if ('layout_two' === $settings['layout_type']) : ?>

	<!--Services Three Start-->
	<section class="services-three">
		<div class="container">
			<div class="section-title text-center">
				<?php
				if (!empty($settings['layout_two_sec_sub_title'])) :
					$this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
					alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
				endif;
				?>
				<?php
				if (!empty($settings['layout_two_sec_title'])) :
					$this->add_inline_editing_attributes('layout_two_sec_title', 'none');
					alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
				endif;
				?>
			</div>
			<div class="row">
				<?php $i = 1;
				foreach ($settings['layout_two_service_items'] as $index => $item) : ?>
					<!--Services Three Single Start-->
					<div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="<?php echo esc_attr($i); ?>00ms">
						<div class="services-three__single">
							<<?php echo esc_attr($item['service_title_tag_layout_two']); ?> class="services-three__title">
								<?php
								if (!empty($item['title'])) :
									alipes_basic_rendered_content($this, $item,  'title', '', 'a');
								endif;
								?>
							</<?php echo esc_attr($item['service_title_tag_layout_two']); ?>>
							<ul class="list-unstyled services-three__list ml-0">
								<?php echo wp_kses($item['content'], 'alipes_allowed_tags'); ?>
							</ul>
						</div>
					</div>
					<!--Services Three Single End-->
				<?php $i++;
				endforeach; ?>
			</div>
		</div>
	</section>
	<!--Services Three End-->

<?php endif; ?>