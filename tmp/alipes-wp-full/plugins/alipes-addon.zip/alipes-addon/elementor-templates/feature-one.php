<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Feature One Start-->
    <section class="feature-one">
        <div class="container">
            <div class="row">
                <?php
                foreach ($settings['feature_list_one'] as $index => $item) :
                ?>
                    <!--Feature One Single Start-->
                    <div class="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="<?php echo esc_attr($index + 1); ?>00ms">
                        <div class="feature-one__single">
                            <div class="feature-one__img">
                                <?php alipes_elementor_rendered_image($item, 'image'); ?>
                            </div>
                            <div class="feature-one__content">
                                <<?php echo esc_attr($item['feature_title_tag_layout_one']); ?> class="feature-one__title">
                                    <?php
                                    if (!empty($item['title'])) :
                                        alipes_basic_rendered_content($this, $item,  'title', '', 'a');
                                    endif;
                                    ?>
                                </<?php echo esc_attr($item['feature_title_tag_layout_one']); ?>>
                                <?php
                                if (!empty($item['subtitle'])) :
                                    alipes_basic_rendered_content($this, $item,  'subtitle', 'feature-one__text', 'p');
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                    <!--Feature One Single End-->
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <!--Feature One End-->
<?php endif; ?>