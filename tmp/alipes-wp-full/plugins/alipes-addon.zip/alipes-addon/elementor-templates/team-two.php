<?php if ('layout_two' == $settings['layout_type']) : ?>

	<!--Team Page Start-->
	<section class="team-carousel-page">
		<div class="container">
			<div class="team-carousel thm-owl__carousel owl-theme owl-carousel carousel-dot-style" data-owl-options='<?php echo esc_attr(alipes_get_owl_options($settings)); ?>'>
				<?php foreach ($settings['layout_two_team_item'] as $index => $item) : ?>
					<!--Team One Single Start-->
					<div class="item">
						<div class="team-one__single">
							<div class="team-one__img-box">
								<div class="team-one__img">
									<?php alipes_elementor_rendered_image($item, 'image'); ?>
								</div>
								<ul class="list-unstyled team-one__social-two">
									<li><a href="#"><i class="fas fa-share-alt"></i></a></li>
								</ul>
								<ul class="list-unstyled team-one__social">
									<?php echo wp_kses($item['social_network'], 'alipes_allowed_tags'); ?>
								</ul>
							</div>
							<div class="team-one__content">
								<<?php echo esc_attr($item['team_name_tag_layout_two']); ?> class="team-one__name">
									<?php
									if (!empty($item['name'])) :
										alipes_basic_rendered_content($this, $item,  'name', '', 'a');
									endif;
									?>
								</<?php echo esc_attr($item['team_name_tag_layout_two']); ?>>
								<?php
								if (!empty($item['designation'])) :
									alipes_basic_rendered_content($this, $item,  'designation', 'team-one__sub-title', $item['team_designation_tag_layout_two']);
								endif;
								?>
							</div>
						</div>
					</div>
					<!--Team One Single End-->
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<!--Team Page End-->

<?php endif; ?>