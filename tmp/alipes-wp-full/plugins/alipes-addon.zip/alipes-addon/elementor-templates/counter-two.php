<?php if ('layout_two' == $settings['layout_type']) : ?>
    <!--Counter Two Start-->
    <section class="counter-two">
        <div class="counter-two__shape-1 float-bob-x">
            <?php alipes_elementor_rendered_image($settings, 'layout_two_bg_image'); ?>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="counter-two__inner">
                        <ul class="list-unstyled counter-two__list">
                            <?php
                            foreach ($settings['counter_list_two'] as $index => $item) :
                            ?>
                                <li class="counter-two__single wow fadeInLeft" data-wow-delay="<?php echo esc_attr($index + 1); ?>00ms">
                                    <div class="counter-two__icon">
                                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                    </div>
                                    <div class="counter-two__content-box">
                                        <h3 class="odometer" data-count="<?php echo esc_attr($item['number']); ?>">00</h3>
                                        <?php
                                        if (!empty($item['title'])) :
                                            alipes_basic_rendered_content($this, $item,  'title', 'counter-two__text', 'p');
                                        endif;
                                        ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Counter Two End-->
<?php endif; ?>