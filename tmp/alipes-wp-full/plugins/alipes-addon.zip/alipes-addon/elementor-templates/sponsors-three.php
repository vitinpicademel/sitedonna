<?php if ('layout_three' == $settings['layout_type']) : ?>
    <!--Brand Three Start-->
    <section class="brand-one brand-two">
        <div class="brand-one__wrap">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="brand-one__inner">
                            <div class="thm-swiper__slider swiper-container" data-swiper-options='<?php echo esc_attr(alipes_get_swiper_options($settings)); ?>'>
                                <div class="swiper-wrapper">
                                    <?php foreach ($settings['sponsor_images'] as $image) : ?>
                                        <div class="swiper-slide">
                                            <?php alipes_elementor_rendered_image($image, 'image') ?>
                                        </div><!-- /.swiper-slide -->
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Brand Three End-->
<?php endif; ?>