<?php if ('layout_three' == $settings['layout_type']) : ?>
    <!--Apartment One Start-->

    <div class="apartment-three__single">
        <div class="apartment-three__img">
            <?php alipes_elementor_rendered_image($settings, 'layout_three_image'); ?>
        </div>
        <div class="apartment-three__content">
            <<?php echo esc_attr($settings['apartment_title_tag_layout_three']); ?> class="apartment-three__title">
                <?php
                if (!empty($settings['layout_three_title'])) :
                    alipes_basic_rendered_content($this, $settings,  'layout_three_title', '', 'a', 'layout_three_url', '');
                endif;
                ?>
            </<?php echo esc_attr($settings['apartment_title_tag_layout_three']); ?>>
            <?php
            if (!empty($settings['layout_three_subtitle'])) :
                alipes_basic_rendered_content($this, $settings,  'layout_three_subtitle', 'apartment-three__sub-title', 'p');
            endif;
            ?>
            <ul class="apartment-three__list list-unstyled ml-0">
                <?php foreach ($settings['layout_three_room_details_list'] as  $item) : ?>
                    <li>
                        <div class="icon">
                            <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                        </div>
                        <?php
                        if (!empty($item['title'])) :
                            alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                        endif;
                        ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!--Apartment One Start-->
<?php endif; ?>