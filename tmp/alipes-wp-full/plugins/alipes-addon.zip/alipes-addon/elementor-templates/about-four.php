<?php if ('layout_four' == $settings['layout_type']) : ?>

    <!--About Building Start-->
    <section class="about-building">
        <div class="about-building__bg" style="background-image: url(<?php echo esc_url($settings['layout_four_bg_shape']['url']); ?>);"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6">
                    <div class="about-building__left">
                        <div class="about-building__img">
                            <?php alipes_elementor_rendered_image($settings, 'layout_four_image'); ?>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6">
                    <div class="about-building__right">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['layout_four_sec_sub_title'])) :
                                $this->add_inline_editing_attributes('layout_four_sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_four_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_four']);
                            endif;

                            if (!empty($settings['layout_four_sec_title'])) :
                                $this->add_inline_editing_attributes('layout_four_sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_four_sec_title', 'section-title__title', $settings['section_title_tag_layout_four']);
                            endif;
                            ?>
                        </div>

                        <?php
                        if (!empty($settings['layout_four_summary_one'])) :
                            alipes_basic_rendered_content($this, $settings,  'layout_four_summary_one', 'about-building__text-1', 'p');
                        endif;

                        if (!empty($settings['layout_four_summary_two'])) :
                            alipes_basic_rendered_content($this, $settings,  'layout_four_summary_two', 'about-building__text-2', 'p');
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--About Building End-->
<?php endif; ?>