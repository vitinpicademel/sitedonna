<?php if ('layout_one' == $settings['layout_type']) : ?>
    <div class="apartment-details-one__list-box">
        <ul class="list-unstyled apartment-details-one__list ml-0">
            <?php
            foreach ($settings['layout_one_apartment_detail_box_list'] as $index => $item) :
            ?>
                <li>
                    <div class="apartment-details-one__list-content">
                        <?php
                        if (!empty($item['title'])) :
                            alipes_basic_rendered_content($this, $item,  'title', '', $item['apartment_box_title_tag_layout_one']);
                        endif;

                        if (!empty($item['subtitle'])) :
                            alipes_basic_rendered_content($this, $item,  'subtitle', '', $item['apartment_box_sub_title_tag_layout_one']);
                        endif;

                        ?>
                    </div>
                </li>
            <?php endforeach; ?>

        </ul>
    </div>
<?php endif; ?>