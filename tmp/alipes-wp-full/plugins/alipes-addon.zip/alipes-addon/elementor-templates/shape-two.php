<?php if ('layout_two' === $settings['layout_type']) : ?>
    <div class="site-footer__shape-1 float-bob-x <?php if ($settings['shape_tablet_position'] != 'yes') : echo esc_attr("d-lg-block d-none");
                                                    endif; ?>">
        <?php alipes_elementor_rendered_image($settings, 'shape_one'); ?>
    </div>
<?php endif; ?>