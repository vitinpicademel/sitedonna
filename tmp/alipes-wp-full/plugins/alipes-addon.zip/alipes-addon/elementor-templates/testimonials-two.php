<?php if ('layout_two' === $settings['layout_type']) : ?>
    <!--Testimonial Two Start-->
    <section class="testimonial-two">
        <div class="testimonial-two__bg" style="background-image: url(<?php echo esc_url($settings['layout_two_bg_image']['url']); ?>);"></div>
        <div class="container">
            <div class="testimonial-two__top">
                <div class="row">
                    <div class="col-xl-6 col-lg-6">
                        <div class="testimonial-two__top-left">
                            <div class="section-title text-left">
                                <?php
                                if (!empty($settings['layout_two_sec_sub_title'])) :
                                    $this->add_inline_editing_attributes('layout_two_sec_sub_title', 'none');
                                    alipes_elementor_rendered_content($this, 'layout_two_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_two']);
                                endif;

                                if (!empty($settings['layout_two_sec_title'])) :
                                    $this->add_inline_editing_attributes('layout_two_sec_title', 'none');
                                    alipes_elementor_rendered_content($this, 'layout_two_sec_title', 'section-title__title', $settings['section_title_tag_layout_two']);
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="testimonial-two__top-right">
                            <?php
                            if (!empty($settings['layout_two_sec_summary'])) :
                                $this->add_inline_editing_attributes('layout_two_sec_summary', 'none');
                                alipes_elementor_rendered_content($this, 'layout_two_sec_summary', 'testimonial-two__top-text', 'p');
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="testimonial-two__bottom">
                <div class="testimonial-two__carousel thm-owl__carousel owl-theme owl-carousel" data-owl-options='<?php echo esc_attr(alipes_get_owl_options($settings)); ?>'>
                    <?php foreach ($settings['layout_two_testimonials'] as $index => $item) :  ?>
                        <!--Testimonial Two Single Start-->
                        <div class="item">
                            <div class="testimonial-two__single">
                                <div class="testimonial-two__client-img-box">
                                    <?php if (!empty($item['image']['url'])) : ?>
                                        <div class="testimonial-two__client-img">
                                            <?php alipes_elementor_rendered_image($item, 'image'); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="testimonial-two__client-info">
                                    <div class="testimonial-two__client-details">
                                        <div class="testimonial-two__client-rating">
                                            <?php for ($i = 0; $i < $item['rating']['size']; $i++) : ?>
                                                <i class="fa fa-star"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <?php
                                        if (!empty($item['name'])) :
                                            alipes_basic_rendered_content($this, $item,  'name', 'testimonial-two__client-name', 'h3');
                                        endif;

                                        if (!empty($item['designation'])) :
                                            alipes_basic_rendered_content($this, $item,  'designation', 'testimonial-two__client-sub-title', 'p');
                                        endif;
                                        ?>
                                    </div>
                                    <div class="testimonial-two__quote">
                                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                    </div>
                                </div>
                                <?php
                                if (!empty($item['testimonial'])) :
                                    alipes_basic_rendered_content($this, $item,  'testimonial', 'testimonial-two__text', 'p');
                                endif;
                                ?>
                            </div>
                        </div>
                        <!--Testimonial Two Single Start-->
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
    <!--Testimonial Two End-->
<?php endif; ?>