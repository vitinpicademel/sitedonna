<?php if ('layout_one' == $settings['layout_type']) : ?>
    <!--Counter One Start-->
    <div class="counter-one">
        <?php if (!empty($settings['bg_image']['url'])) : ?>
            <div class="counter-one__bg float-bob-x" style="background-image: url(<?php echo esc_url($settings['bg_image']['url']); ?>);"></div>
        <?php endif; ?>
        <?php if (is_array($settings['counter_list'])) : ?>
            <div class="container">
                <div class="row">
                    <?php
                    foreach ($settings['counter_list'] as $index => $item) :
                    ?>
                        <!--Counter One Single Start-->
                        <div class="col-xl-3 col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="<?php echo esc_attr($index + 1); ?>00ms">
                            <div class="counter-one__single">
                                <div class="counter-one__top">
                                    <div class="counter-one__shape"></div>
                                    <div class="counter-one__icon">
                                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                    </div>
                                </div>
                                <div class="counter-one__count-box">
                                    <h3 class="odometer" data-count="<?php echo esc_attr($item['number']); ?>">00</h3>
                                    <?php
                                    if (!empty($item['title'])) :
                                        alipes_basic_rendered_content($this, $item,  'title', 'counter-one__text', 'p');
                                    endif;
                                    ?>
                                </div>
                            </div>
                        </div>
                        <!--Counter One Single End-->
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <!--Counter One Start-->
<?php endif; ?>