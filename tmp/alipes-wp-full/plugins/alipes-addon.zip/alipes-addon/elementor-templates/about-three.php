<?php if ('layout_three' == $settings['layout_type']) : ?>
    <!--About Three Start-->
    <section class="about-three">
        <div class="about-three__shape-2 float-bob-y"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-6">
                    <div class="about-three__left">
                        <div class="about-three__img-box">
                            <div class="about-three__img-1">
                                <?php alipes_elementor_rendered_image($settings, 'layout_three_shape_one'); ?>
                            </div>
                            <div class="about-three__img-2">
                                <?php alipes_elementor_rendered_image($settings, 'layout_three_shape_two'); ?>
                            </div>
                            <div class="about-three__shape-1"></div>
                            <div class="about-two__big-text"><?php echo esc_html($settings['layout_three_bigtext']); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="about-three__right">
                        <div class="section-title text-left">
                            <?php
                            if (!empty($settings['layout_three_sec_sub_title'])) :
                                $this->add_inline_editing_attributes('layout_three_sec_sub_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_three_sec_sub_title', 'section-title__tagline', $settings['section_sub_title_tag_layout_three']);
                            endif;

                            if (!empty($settings['layout_three_sec_title'])) :
                                $this->add_inline_editing_attributes('layout_three_sec_title', 'none');
                                alipes_elementor_rendered_content($this, 'layout_three_sec_title', 'section-title__title', $settings['section_title_tag_layout_three']);
                            endif;
                            ?>
                        </div>
                        <?php
                        if (!empty($settings['layout_three_summary'])) :
                            alipes_basic_rendered_content($this, $settings,  'layout_three_summary', 'about-three__text', 'p');
                        endif;
                        ?>
                        <ul class="about-three__points list-unstyled ml-0">
                            <?php foreach ($settings['layout_three_features_list'] as $item) : ?>
                                <li>
                                    <div class="icon">
                                        <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true', 'class' => ' '], 'span'); ?>
                                    </div>
                                    <div class="text">
                                        <?php
                                        if (!empty($item['title'])) :
                                            alipes_basic_rendered_content($this, $item,  'title', '', 'p');
                                        endif;
                                        ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--About Three End-->

<?php endif; ?>