<?php

/**
 * alipes functions for getting inline styles from theme customizer
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package alipes
 */

if (!function_exists('alipes_theme_customizer_styles')) :
	function alipes_theme_customizer_styles()
	{

		// alipes color option

		$alipes_inline_style = '';
		$alipes_inline_style .= ':root {
			--alipes-primary: ' . get_theme_mod('theme_primary_color', sanitize_hex_color('#f6f4f1')) . ';
			--alipes-primary-rgb: ' . alipes_hex_to_rgb(get_theme_mod('theme_primary_color', sanitize_hex_color('#f6f4f1'))) . ';

			--alipes-base: ' . get_theme_mod('theme_base_color', sanitize_hex_color('#cd8c66')) . ';
			--alipes-base-rgb: ' . alipes_hex_to_rgb(get_theme_mod('theme_base_color', sanitize_hex_color('#cd8c66'))) . ';

			--alipes-black: ' . get_theme_mod('theme_black_color', sanitize_hex_color('#0e2207')) . ';
			--alipes-black-rgb: ' . alipes_hex_to_rgb(get_theme_mod('theme_black_color', sanitize_hex_color('#0e2207'))) . ';
		}';

		$alipes_inner_banner_bg = get_theme_mod('page_header_bg_image');
		$alipes_inline_style .= '.page-header-bg { background-image: url(' . $alipes_inner_banner_bg . '); } ';

		$alipes_preloader_icon = get_theme_mod('preloader_image');
		if ($alipes_preloader_icon) {
			$alipes_inline_style .= '.preloader .preloader__image { background-image: url(' . $alipes_preloader_icon . '); } ';
		}

		if (is_page()) {


			$alipes_page_primary_color = empty(get_post_meta(get_the_ID(), 'alipes_primary_color', true)) ? get_theme_mod('theme_primary_color', sanitize_hex_color('#f6f4f1')) : get_post_meta(get_the_ID(), 'alipes_primary_color', true);

			$alipes_page_base_color = empty(get_post_meta(get_the_ID(), 'alipes_base_color', true)) ? get_theme_mod('theme_base_color', sanitize_hex_color('#cd8c66')) : get_post_meta(get_the_ID(), 'alipes_base_color', true);

			$alipes_page_black_color = empty(get_post_meta(get_the_ID(), 'alipes_black_color', true)) ? get_theme_mod('theme_black_color', sanitize_hex_color('#0e2207')) : get_post_meta(get_the_ID(), 'alipes_black_color', true);

			$alipes_inline_style .= ':root {
				--alipes-primary: ' . $alipes_page_primary_color . ';
				--alipes-primary-rgb: ' . alipes_hex_to_rgb($alipes_page_primary_color) . ';
				--alipes-base: ' . $alipes_page_base_color . ';
				--alipes-base-rgb: ' . alipes_hex_to_rgb($alipes_page_base_color) . ';
				--alipes-black: ' . $alipes_page_black_color . ';
				--alipes-black-rgb: ' . alipes_hex_to_rgb($alipes_page_black_color) . ';
			}';

			$alipes_page_header_bg = empty(get_post_meta(get_the_ID(), 'alipes_set_header_image', true)) ? get_theme_mod('page_header_bg_image') : get_post_meta(get_the_ID(), 'alipes_set_header_image', true);

			$alipes_inline_style .= '.page-header-bg { background-image: url(' . $alipes_page_header_bg . '); }';
		}

		if (is_singular('post')) {
			$alipes_post_header_bg = empty(get_post_meta(get_the_ID(), 'alipes_set_header_image', true)) ? get_theme_mod('page_header_bg_image') : get_post_meta(get_the_ID(), 'alipes_set_header_image', true);

			$alipes_inline_style .= '.page-header-bg  { background-image: url(' . $alipes_post_header_bg . '); }';
		}


		wp_add_inline_style('alipes-style', $alipes_inline_style);
	}
endif;

add_action('wp_enqueue_scripts', 'alipes_theme_customizer_styles');
