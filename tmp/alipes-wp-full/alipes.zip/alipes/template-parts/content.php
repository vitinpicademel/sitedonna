<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package alipes
 */
$tag_name = get_the_tags();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if (has_post_thumbnail()) : ?>
		<div class="news-details__img">
			<?php the_post_thumbnail('alipes_blog_770X428'); ?>
			<div class="news-details__date">
				<p><?php echo get_the_date(); ?></p>
			</div>
		</div>
	<?php endif; ?>

	<div class="news-details__content clearfix">
		<ul class="list-unstyled news-details__meta ml-0">
			<?php if (has_tag()) : ?>
				<li><a href="<?php the_permalink(); ?>"><i class="fas fa-tag"></i><?php echo esc_html($tag_name[0]->name); ?></a>
				</li>
			<?php endif; ?>
			<li><?php alipes_posted_by(); ?></li>
			<?php if (!is_single() && !post_password_required() && (comments_open() || get_comments_number())) : ?>
				<li><?php alipes_comment_count(); ?></li>
			<?php endif; ?>
		</ul>

		<?php
		the_content(
			sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__('Continue reading<span class="screen-reader-text"> "%s"</span>', 'alipes'),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				wp_kses_post(get_the_title())
			)
		);

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__('Pages:', 'alipes'),
				'after'  => '</div>',
			)
		);
		?>
	</div>
	<div class="news-details__bottom">
		<?php alipes_entry_footer(); ?>
	</div>

</article><!-- #post-<?php the_ID(); ?> -->