<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package alipes
 */
$tag_name = get_the_tags();
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('news-sidebar__single'); ?>>
	<?php if (has_post_thumbnail()) : ?>
		<div class="news-sidebar__img">
			<?php the_post_thumbnail('alipes_blog_770X428');  ?>
			<div class="news-sidebar__date">
				<?php echo get_the_date(); ?>
			</div>
		</div>
	<?php endif; ?>
	<div class="news-sidebar__content-box">
		<ul class="list-unstyled news-sidebar__meta ml-0">
			<?php if (has_tag()) : ?>
				<li><a href="<?php the_permalink(); ?>"><i class="fas fa-tag"></i><?php echo esc_html($tag_name[0]->name); ?></a>
				</li>
			<?php endif; ?>
			<li><?php alipes_posted_by(); ?></li>
		</ul>
		<h3 class="news-sidebar__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h3>
		<?php $alipes_excerpt_count = apply_filters('alipes_excerpt_count', 39); ?>
		<p class="news-sidebar__text"><?php alipes_excerpt($alipes_excerpt_count); ?></p>
		<div class="news-sidebar__bottom">
			<a href="<?php the_permalink(); ?>" class="news-sidebar__read-more"><?php esc_html_e('Read More', 'alipes'); ?><span class="icon-right-arrow"></span></a>
		</div>
	</div>

</article><!-- #post-<?php the_ID(); ?> -->